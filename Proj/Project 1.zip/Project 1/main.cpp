/* 
 * File:   main.cpp
 * Author: Jacob Trubey
 *
 * Created on April 23, 2015, 4:20 PM
 */

//Library includes Here!!!
#include <iostream>
#include <string>
using namespace std;

//Global Constants Here!!!

//Function Prototypes Here!!!
void Menu();
int getN();
void def(int);
void problem1();
void problem2();
void problem3();
void problem4();
void problem5();
void problem6();

//Begin Execution Here!!!
int main(int argv,char *argc[]){
    int inN;
    do{
        Menu();
        inN=getN();
        switch(inN){
        case 1:    problem1();break;
        case 2:    problem2();break;
        case 3:    problem3();break;
        case 4:    problem4();break;
        case 5:    problem5();break;
        case 6:    problem6();break;
        default:   def(inN);}
    }while(inN>=1&&inN<=2);
    return 0;
}

void Menu(){
    cout<<"Welcome to The Life of Jacob, a terribly unfortunate game. Please select from the following menu options."<<endl<<endl;
    
    cout<<"Type 1 to start game"<<endl;
    cout<<"Type 2 to see high scores"<<endl;
    cout<<"Type anything else to exit \n"<<endl;
}

int getN(){
        int inN;
        cin>>inN;
        cout<<endl;
        return inN;
}

void problem1(){
    
    string name = "Jacob Trubey";
    char nChoice;
    
        cout<<"You awake to find that you are Jacob Trubey. This is not good..."<<endl;
        cout<<"You have the luck of the Irish, that is to say, you are not a very luck person."<<endl;
        cout<<"Your goal is to make it through the day without something terrible happening to you,"<<endl;
        cout<<"however, you should know that your odds of accomplishing this goal are absurdly low. Godspeed."<<endl<<endl;
        
        cout<<"Would you like to go by a different name? Enter Y for yes, or N for no."<<endl;
        cin>>nChoice;
        cout<<endl;
        
        do{
            if (nChoice == 'Y'){
                do{
                    nChoice = 'N';
                    cout<<"Please enter the name that you would like to go by."<<endl;
                    cin.ignore();
                    getline(cin, name);
                    cout<<endl;
                    cout<<"You entered the name "<<name<<". Is this okay? Please enter Y for yes, or N for no."<<endl;
                    cin>>nChoice;
                    cout<<endl;

                    if(nChoice != 'Y' && nChoice != 'N'){
                        cout<<"That is not a valid choice option. Please enter Y for yes, or N for no."<<endl;
                        cin>>nChoice;
                        cout<<endl;
                    }
                }while(nChoice != 'Y');
            }
            else if (nChoice != 'N' && nChoice != 'Y'){
                cout<<"That is not a valid choice option. Please enter Y for yes, or N for no."<<endl;
                cin>>nChoice;
                cout<<endl;
                if (nChoice == 'Y'){
                    do{
                        nChoice = 'N';
                        cout<<"Please enter the name that you would like to go by."<<endl;
                        cin.ignore();
                        getline(cin, name);
                        cout<<endl;
                        cout<<"You entered the name "<<name<<". Is this okay? Please enter Y for yes, or N for no."<<endl;
                        cin>>nChoice;
                        cout<<endl;

                        if(nChoice != 'Y' && nChoice != 'N'){
                            cout<<"That is not a valid choice option. Please enter Y for yes, or N for no."<<endl;
                            cin>>nChoice;
                            cout<<endl;
                            do{
                                cout<<"That is not a valid choice option. Please enter Y for yes, or N for no."<<endl;
                                cin>>nChoice;
                                cout<<endl;
                            }while(nChoice != 'Y' && nChoice != 'N');
                        }
                    }while(nChoice != 'Y');
                }
            }
        }while(nChoice != 'N' && nChoice != 'Y');
        
        cout<<"Your name is thus "<<name<<"! Incidentally this does not improve your odds of avoiding imminent peril..."<<endl<<endl;
}

void problem2(){
        cout<<"In problem # 2"<<endl<<endl;
}

void problem3(){
        cout<<"In problem # 3"<<endl<<endl;
}

void problem4(){
        cout<<"In problem # 4"<<endl<<endl;
}

void problem5(){
        cout<<"In problem # 5"<<endl<<endl;
}

void problem6(){
        cout<<"In problem # 6"<<endl<<endl;
}

void def(int inN){
        cout<<"Exiting program..."<<endl;
} 