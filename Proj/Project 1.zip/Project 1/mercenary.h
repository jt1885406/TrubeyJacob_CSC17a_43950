/* 
 * File:   mercenary.h
 * Author: Jacob Trubey
 *
 * Created on May 4, 2015, 7:11 PM
 */

#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;

#ifndef MERCENARY_H
#define	MERCENARY_H

struct Mercenary{
    
    string name;
    int attack;
    int defense;
    bool stable;
};

#endif	/* MERCENARY_H */

