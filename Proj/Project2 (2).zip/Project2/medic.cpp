#include "Medic.h"
#include <cstdlib>
#include <ctime>
#include <Vector>

Medic::Medic(){
	stats.attack = 0;
	stats.defense = 0;
	stats.name = "merc";
        stats.type = "Medic";
	stats.stable = true;
}

Medic::Medic(std::string n){
	stats.attack = 0;
	stats.defense = 0;
	stats.name = n;
        stats.type = "Medic";
	stats.stable = true;
	abilityUsed = false;
}

Medic::Medic(int a, int b){
	stats.attack = a;
	stats.defense = b;
	stats.name = "merc";
        stats.type = "Medic";
	stats.stable = true;
}

Medic::Medic(int a, int b, std::string n){
	stats.attack = a;
	stats.defense = b;
	stats.name = n;
        stats.type = "Medic";
	stats.stable = true;
	
}

Medic::Medic(int a, int b, std::string n, bool s){
	stats.attack = a;
	stats.defense = b;
	stats.name = n;
        stats.type = "Medic";
	stats.stable = s;
}

bool Medic::useAbility(int &number, Mercenary* mercs){
	bool tempBool = abilityUsed;        
        srand(time(0)); 
        int numGren = Mercenary::platoon.numGren;
        int numMedic = Mercenary::platoon.numMedic;
        int total = numGren + numMedic;
        int chance =  rand() % 2;
        int lucky = rand() % total;
        
        cout<< "Medic ability being used..." <<endl<<endl;
        if (chance == 1){
            if(abilityUsed == true){
                    return false;
            }
            
            else{
                abilityUsed = false;

                bool fixed = false;

                do{
                    lucky = rand() % total;

                    if(mercs[lucky].getStats().stable == false){
                            changeStat(3, mercs[0]);
                            lucky = true;
                            cout << mercs[lucky].getName() << " was resuscitated by " << getName();
                    }
                 }while(lucky == false);
            }
        }

	return tempBool;
}


Medic::~Medic(){}

