/* 
 * File:   main.cpp
 * Author: Jacob Trubey
 *
 * Created on May 27, 2015, 5:18 PM
 */

//Library includes Here!!!
#include "grenadier.h"
#include "Medic.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <typeinfo>
using namespace std;

//Global Constants Here!!!

//Function Prototypes Here!!!
void Menu();                                                                    //function to display main game menu
int getN();                                                                     //function to take in user's menu choice
void def(int);                                                                  //function to display program exit
void viewTutorial();                                                            //function to view game tutorial
void startGame();                                                               //function to start game
void viewScores();                                                              //function to view high scores

//Begin Execution Here!!!
int main(int argv,char *argc[]){
    
    int inN;                                                                    //user's menu choice
    
    do{
        Menu();                                                                 //call function to display main game menu
        inN=getN();                                                             //call function to take in user's menu choice
        switch(inN){                                                            //choose from menu options
        case 1:    viewTutorial();break;                                        //call function to view game tutorial
        case 2:    startGame();break;                                           //call function to start game
        case 3:    viewScores();break;                                          //call function to view high scores
        default:   def(inN);}                                                   //call function to display program exit
    }while(inN>=1&&inN<=3);
    return 0;                                                                   //exit program
}

void Menu(){
    cout<<"Welcome to Mercenary Mission!"<<endl;                                //display main game menu
    cout<<"(a turn based strategy game of)"<<endl;
    cout<<"(money and hired mercenaries)"<<endl<<endl;
    cout<<"_____________________________________________________________________"<<endl<<endl;
    
    cout<<"Please type the number associated with the option from the following menu list."<<endl<<endl;
    
    cout<<"1) View Tutorial"<<endl;
    cout<<"2) Start Game"<<endl;
    cout<<"3) View High Scores"<<endl;
    cout<<"(type anything else to exit)"<<endl<<endl;
}

int getN(){
        int inN;                                                                //take in user's menu choice
        cin>>inN;
        cout<<endl;
        cout<<"_____________________________________________________________________"<<endl<<endl;
        return inN;
}

void viewTutorial(){
    //display game tutorial
    cout<<"Starting The Game: Choosing an amount of mercenaries to train: When starting the game,"<<endl
        <<"you are given $200,000 which you start using by picking an amount of mercenaries to train with."<<endl
        <<"This is the only time during the game that you will have this option, so you will have to apply"<<endl
        <<"some thought or strategy here."<<endl<<endl
        <<"Increasing Abilities/Resuscitating Mercenaries: Whatever funds you have left over from training"<<endl
        <<"your team of mercenaries can then be used to increase each of your mercenaries’ abilities."<<endl
        <<"These abilities include ‘attack’, which is a determining factor in dealing a lethal attack to an enemy"<<endl
        <<"(based on the idea of good equipment and the ability to use it effectively), and ‘defense’, which is a"<<endl
        <<"determining factor on whether or not an  enemy can deal a lethal attack to your mercenary (also based"<<endl
        <<"on the idea of equipment and personal skill). Increasing these statistics costs money, but each have"<<endl
        <<"their own perks in a battle sequence, and it is up to you to determine which is more worth your money"<<endl
        <<"for given circumstances. Another option in the ability increasing function is the option to resuscitate"<<endl
        <<"any injured mercenaries, but this option is naturally only useable if you have injured mercenaries."<<endl<<endl
        <<"Choosing a job: There are 1 of 3 types of jobs to choose from, in descending order of difficulty"<<endl
        <<"from lowest to highest. Each job has a risk rating that demonstrates this difficulty (low, moderate, high)."<<endl
        <<"Beginning players will be most likely unable to survive the moderate difficulty level, let alone the"<<endl
        <<"high level, so it would be a good idea to spend some time taking low difficulty level jobs of escorting"<<endl
        <<"dignitaries and using your monetary rewards to increase your mercenaries abilities until you feel that"<<endl
        <<"they are ready for the more difficult mission."<<endl<<endl
        <<"Engaging A Mission/Battle Sequence: The battle sequence starts when a mission is accepted and engaged."<<endl
        <<"This sequence involves a random generation of enemies (The possible amounts depending on the difficultly"<<endl
        <<"of the mission) and then more random generation determines which of your mercenaries are personally"<<endl
        <<"engaged by an enemy, and even further random generation uses variations on your mercenaries base attack"<<endl
        <<"score, vs. the enemy’s randomly generated defense, and the enemy’s randomly generated attack score, based"<<endl
        <<"on your mercenaries base defense. A successful hit is all that is needed to defeat either the enemy or"<<endl
        <<"your mercenary (keeping in mind unsuccessful attacks are evaded/blocked by body armor, or considered"<<endl
        <<"negligible, and that successful attacks or those inflicted by firearms or other equally lethal weapons"<<endl
        <<"with enough damage to defeat the opponent). After the two attack each other simultaneously, it is then"<<endl
        <<"determined how much of an attack score was given by both opponents and who, if any, was defeated as a"<<endl
        <<"result. If all of your mercenaries are defeated before defeating all of the enemies, you fail the mission"<<endl
        <<"with no reward. If all of the enemies are defeated  before all of your mercenaries are, then the mission"<<endl
        <<"is a success and your reward is earned. If you defeat the last enemy while that enemy simultaneously defeats"<<endl
        <<"your last mercenary, you successfully complete the mission and receive the reward, but are then unable to"<<endl
        <<"accept any other jobs until you resuscitate one of your mercenaries. Should you have insufficient funds"<<endl
        <<"to resuscitate a mercenary and all of your mercenaries are injured, it is up to you to quit the game from"<<endl
        <<"the “Job List” menu as your only other option is to continue to go through the other menu options to no avail."<<endl<<endl
        <<"Saving Your Score: After quitting the game you have the option to save your score. If you choose yes, you are"<<endl
        <<"then prompted to enter your initials which will precede the high score you earned from playing the game."<<endl
        <<"Your high score is based on money earned, services purchased, and mission ready (non-injured) mercenaries"<<endl
        <<"upon quitting. This score will then be saved to a file named “score”, which will keep a log of all previously"<<endl
        <<"saved scores on your computer."<<endl<<endl
        <<"Viewing High Scores: Selecting the option to “View High Scores” allows you to view the file called “scores”"<<endl
        <<"which contains the initials and accompanying high scores of previously played games."<<endl<<endl;
}

void startGame(){
    
    int funds = 200000;                                                         //starting funds
    int numMrc;                                                                 //size of mercenary array
    
    bool misRed = true;                                                         //boolean flag to determine if mercenary group is ready for a mission
	//Medic medics[];
	//Grenadier grenadiers[];
    Mercenary::platoon = Mercenary::amtMrc(&funds, &numMrc);                    //call function to calculate amount of mercenaries
   
    int numGren = Mercenary::platoon.numGren;                                   //number of grenadiers
    int numMedic = Mercenary::platoon.numMedic;                                 //number of medics
    int total = numGren + numMedic;                                             //total amount of mercenaries
        //Mercenary mercenaries[total];
    //Mercenary* mercenaries = new Mercenary[total];
    Mercenary* mercenaries;                           //dynamically allocate mercenary array
    Grenadier grenadiers[numGren];                                              //array of grenadiers
    Medic medics[numMedic];                                                     //array of medics
    numMrc = total;                                                             //total amount of mercenaries
        
    mercenaries = new Grenadier[numGren];
//    int i = 0;
//    
//     for(i = 0; i < numGren; i++){                                              //fill mercenary array with grenadiers
//        mercenaries[i] = &grenadiers[i];
//    }
//    
//    for(i = 0; i < numMedic; i++){                                              //fill mercenary array with medics
//        mercenaries[i + numGren] = &medics[i];
//    }
    

     
    (mercenaries)->trainMrc(&funds, &numMrc, mercenaries);                    //call function to set base stats of mercenaries
    (mercenaries)->incAbl(&funds, &numMrc, mercenaries);                      //call function to increase stats of mercenaries
    (mercenaries)->chooseJob(&funds, &numMrc, &misRed, mercenaries);          //call function to choose job for mercenary group
    (mercenaries)->saveScore(&funds,&numMrc, mercenaries);                    //call function to save score
    
    cout<<"Thank you for playing."<<endl<<endl;
    
    cout<<"_____________________________________________________________________"<<endl<<endl;
    
    delete [] mercenaries;                                                      //deallocate memory
    mercenaries = 0;

}

void viewScores(){
    const int SIZE = 3;                                                         //size of initials array
    char initials[SIZE] = {' ',' ',' '};                                        //array of initials for saved scores
    int highScore = 0;                                                          //high score of saved games
    
    fstream file;
    file.open("scores.txt", ios::in | ios::binary);                             //open file of saved scores
    
    cout<<"High Scores"<<endl<<endl;
    
    file.read(initials, sizeof(initials));                                      //read in first set of initials
    file.read(reinterpret_cast<char *>(&highScore), sizeof(highScore));         //read in first high score
    
    while (!file.eof()){                                                        //display first set of initials and high score and read in subsequent sets of initials and high scores
        for(int count = 0; count < SIZE; count++)
            cout<<initials[count];
        cout<<" "<<highScore<<endl;
        
        file.read(initials, sizeof(initials));
        file.read(reinterpret_cast<char *>(&highScore), sizeof(highScore));
    }
    
    cout<<"_____________________________________________________________________"<<endl<<endl;
    
    file.close();                                                               //close file of saved scores
}

void def(int inN){
    
        cout<<"Exiting the program..."<<endl;                                   //display program exit
}
