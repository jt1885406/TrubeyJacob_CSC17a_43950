#ifndef Grenadier_H_
#define Grenadier_H_

#include "Mercenary.h"
#include <iostream>
#include <string>

class Grenadier : public Mercenary                                              //inherited grenadier mercenary class
{
	public:	
		Grenadier();
		Grenadier(std::string);
		Grenadier(int a, int b);
		Grenadier(int a, int b, std::string n);
		Grenadier(int a, int b, std::string n, bool s);
		~Grenadier();
		bool useAbility(int&, Mercenary*);
	
	private:
	protected:
};

#endif
