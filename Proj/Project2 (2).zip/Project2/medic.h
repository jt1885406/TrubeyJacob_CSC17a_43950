
#ifndef Medic_H_
#define Medic_H_

#include "Mercenary.h"
#include <iostream>
#include <string>

class Medic : public Mercenary                                                  //inherited medic mercenary class
{
	public:	
		Medic();
		Medic(std::string);
		Medic(int a, int b);
		Medic(int a, int b, std::string n);
		Medic(int a, int b, std::string n, bool s);
		~Medic();
		bool useAbility(int&, Mercenary*);
	
	private:
	protected:
};

#endif
