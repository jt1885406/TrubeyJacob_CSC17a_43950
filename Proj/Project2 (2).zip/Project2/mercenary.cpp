
#include "Mercenary.h"
#include <ctime>
#include <cstdlib>
#include <fstream>
#include <typeinfo>

Mercenary::Army Mercenary::platoon;

Mercenary::Mercenary(){                                                         //initialize values for Mercenary class
	stats.attack = 0;
	stats.defense = 0;
	stats.name = "merc";
        stats.type = "Mercenary";
	stats.stable = true;
}

Mercenary::Mercenary(std::string n){
	stats.attack = 0;
	stats.defense = 0;
	stats.name = n;
        stats.type = "Mercenary";
	stats.stable = true;
	abilityUsed = false;
}

Mercenary::Mercenary(int a, int b){
	stats.attack = a;
	stats.defense = b;
	stats.name = "merc";
        stats.type = "Mercenary";
	stats.stable = true;
}

Mercenary::Mercenary(int a, int b, std::string n){
	stats.attack = a;
	stats.defense = b;
	stats.name = n;
        stats.type = "Mercenary";
	stats.stable = true;
	
}

Mercenary::Mercenary(int a, int b, std::string n, bool s){
	stats.attack = a;
	stats.defense = b;
	stats.name = n;
        stats.type = "Mercenary";
	stats.stable = s;
}

Mercenary::~Mercenary(){}                                                       //Destructor

void Mercenary::setAttack(int a){                                               //input validation for negative numbers for attack entered user
	if(a < 0){
		a = 0;
	}
	
		stats.attack = a;
}

void Mercenary::setDefense(int d){                                              //input validation for negative numbers for defense entered user
	if(d < 0){
		d = 0;
	}
	
	stats.defense = d;
}

std::string Mercenary::getType(){                                               //access mercenary type
    return stats.type;
}

int Mercenary::getAttack(){                                                     //access mercenary attack
	return stats.attack;
}

int Mercenary::getDefense(){                                                    //access mercenary defense
	return stats.defense;
}

void Mercenary::display(){                                                      //display mercenary info
	cout << "Name: " << stats.name << endl
		 << "Attack: " << stats.attack << endl
		 << "Defense: " << stats.defense << endl
		 << "Stable?: " << (stats.stable ? "true" : "false");
}

bool Mercenary::useAbility(int&, Mercenary* mercs){                             //virtual function for derived classes special abilities
	cout<< "Ability being used.." <<endl<<endl;
	//cout << endl << getType() << endl;
}

std::string Mercenary::getName(){                                               //access mercenary name
	return stats.name;
}

Mercenary::Army Mercenary::amtMrc(int *funds, int *numMrc){
    
    cout<<"Your current funds are $"<<*funds<<"."<<endl;              //display current funds and prompt user to create mercenaries
    cout<<"(each mercenary costs $20000 to train)"<<endl;
    cout<<"How many grenadiers do you want to train?"<<endl;
    std::cin>>*numMrc;                                                          //take in amount of grenadiers from user
    cout<<endl;
    if (*numMrc<0 || *numMrc>10){                                               //validate input amount of grenadiers
	do{
            cout<<"That is an invalid amount."<<endl;
            cout<<"Please enter a valid amount of grenadiers to train."<<endl;
            std::cin>>*numMrc;
            cout<<endl;
	}while(*numMrc<1 || *numMrc>10);
    }
    Mercenary::platoon.numGren = *numMrc;                                                  //set amount of grenadiers
    
    *funds = *funds - 20000*(*numMrc);                                          //decrement funds
    cout<<"Your current funds are $"<<*funds<<"."<<endl<<endl;   //display current funds
    
//    cout<<"How many medics do you want to train?"<<endl;              //take in amount of medics from user
//    std::cin>>*numMrc;
//    cout<<endl;
//    if (*numMrc<0 || *numMrc>10){                                               //validate input amount of medics
//	do{
//            cout<<"That is an invalid amount."<<endl;
//            cout<<"Please enter a valid amount of medics to train."<<endl;
//            std::cin>>*numMrc;
//            cout<<endl;
//	}while(*numMrc<1 || *numMrc>10);
//    }
//    
//    Mercenary::platoon.numMedic = *numMrc;                                      //set amount of medics
Mercenary::platoon.numMedic = 0;
    
    //*funds = *funds - 20000*(*numMrc);                                          //decrement funds
    cout<<"Your current funds are $"<<*funds<<"."<<endl<<endl;   //display current funds
    
    return platoon;                                                             //return mercenary info
}

void Mercenary::trainMrc(int *funds, int *numMrc, Mercenary *mercenaries){
    
    std::cin.ignore();
    
    cout << "\nNumber mercenaries: " << *numMrc << endl;
    
    for(int count = 0; count < *numMrc; count++){                               //set stats for group of mercenaries
        cout<<"\nPlease enter mercenary number "<<count+1<<"'s name."<<endl;
        getline(std::cin, (*(mercenaries + count)).stats.name);
        cout << endl;
        (*(mercenaries + count)).stats.defense = 5;
        (*(mercenaries + count)).stats.attack = 3;
        (*(mercenaries + count)).stats.stable = true;
    }
    
    cout<<"Training "<<*numMrc<<" mercenaries..."<<endl<<endl;
    
    cout<<"_____________________________________________________________________"<<endl<<endl;
    
    cout<<"Your team of mercenaries is as follows:"<<endl<<endl; //display stats for group of mercenaries
    for(int count = 0; count < *numMrc; count++){
        cout<<(*(mercenaries + count)).stats.name<<endl;
        cout<<"stats.defense: "<<(*(mercenaries + count)).stats.defense<<endl;
        cout<<"stats.attack: "<<(*(mercenaries + count)).stats.attack<<endl;
        if ((*(mercenaries + count)).stats.stable == true)
            cout<<"health status: mission ready"<<endl;
        else
            cout<<"health status: injured"<<endl<<endl;
        cout<<"type: "<<(*(mercenaries + count)).stats.type<<endl<<endl;
    }
    
    cout<<"_____________________________________________________________________"<<endl<<endl;
}

void Mercenary::incAbl(int *funds, int *numMrc, Mercenary *mercenaries){
    
    char incChc;                                                                //choice to increase abilities of a mercenary
    int mrcChc;                                                                 //choice of mercenary to increase abilities of
    char conChc;                                                                //confirm choice of which mercenary's abilities to increase
    char ablChc;                                                                //choice of ability to increase
    
    cout<<"Would you like to improve the equipment of any of your mercenaries or resuscitate them?"<<endl;
    cout<<"(improving defensive equipment increases a mercenary's defense and costs $20000 per mercenary)"<<endl;
    cout<<"{improving offensive equipment increases a mercenary's attack and costs $50000 per mercenary)"<<endl;
    cout<<"(resuscitation changes a mercenary's status from injured to mission ready and costs $100000 per mercenary)"<<endl;
    cout<<"Please enter Y for yes, or anything else for no."<<endl;
    std::cin>>incChc;
    cout<<endl;
    
    cout<<"_____________________________________________________________________"<<endl<<endl;
        
    while(incChc == 'Y'){
        cout<<"Which mercenary would you like to equip or resuscitate?"<<endl;
        cout<<"Enter number from list associated with mercenary."<<endl<<endl;
        for(int count = 0; count < *numMrc; count++){
            cout<<count + 1<<") "<<(*(mercenaries + count)).stats.name<<endl;
            cout<<"defense: "<<(*(mercenaries + count)).stats.defense<<endl;
            cout<<"attack: "<<(*(mercenaries + count)).stats.attack<<endl;
            if ((*(mercenaries + count)).stats.stable == true)
                cout<<"health status: mission ready"<<endl<<endl;
            else
                cout<<"health status: injured"<<endl<<endl;
            cout<<"type: "<<(*(mercenaries + count)).stats.type<<endl;
        }
        
        std::cin>>mrcChc;
        cout<<endl;
        
        if (mrcChc<1 || mrcChc>(*numMrc)){
            do{
                cout<<"That is an invalid entry."<<endl;
                cout<<"Please enter a valid entry from the list of mercenaries."<<endl;
                std::cin>>mrcChc;
                cout<<endl;
            }while(mrcChc<1 || mrcChc>(*numMrc));
            
            cout<<"_____________________________________________________________________"<<endl<<endl;
        }
        
        cout<<"You've chosen to increase the abilities of "<<(*(mercenaries + mrcChc - 1)).stats.name<<". Is this correct?"<<endl;
        cout<<"Please enter Y for yes, or anything else for no."<<endl;
        std::cin>>conChc;
        cout<<endl;
        
        cout<<"_____________________________________________________________________"<<endl<<endl;
        
        while(conChc == 'Y'){
            cout<<"What would you like to improve for "<<(*(mercenaries + mrcChc - 1)).stats.name<<"?"<<endl;
            cout<<"(please enter the letter associated with the option from the list, or anything else to go back)"<<endl<<endl;
            cout<<"Your current funds are $"<<*funds<<"."<<endl<<endl;
            
            cout<<"D) Improve Defensive Equipment: $20000"<<endl;
            cout<<"O) Improve Offensive Equipment: $50000"<<endl;
            cout<<"R) Resuscitate: $100000"<<endl;
            std::cin>>ablChc;
            cout<<endl;
            
            
            if (ablChc == 'D'){
                if (*funds < 20000){
                    cout<<"You have insufficient funds."<<endl<<endl;
                    
                    cout<<"_____________________________________________________________________"<<endl<<endl;
                }
                else{
                    (*(mercenaries + mrcChc - 1)).stats.defense++;
                    *funds = *funds - 20000;
                    cout<<(*(mercenaries + mrcChc - 1)).stats.name<<"'s defense is now "<<(*(mercenaries + mrcChc - 1)).stats.defense<<"."<<endl;
                    cout<<"Your current funds are $"<<*funds<<"."<<endl<<endl;
                    
                    cout<<"_____________________________________________________________________"<<endl<<endl;
                }
            }
            else if (ablChc == 'O'){
                if (*funds < 50000){
                    cout<<"You have insufficient funds."<<endl<<endl;
                    
                    cout<<"_____________________________________________________________________"<<endl<<endl;
                }
                else{
                    (*(mercenaries + mrcChc - 1)).stats.attack++;
                    *funds = *funds - 50000;
                    cout<<(*(mercenaries + mrcChc - 1)).stats.name<<"'s attack is now "<<(*(mercenaries + mrcChc - 1)).stats.attack<<"."<<endl;
                    cout<<"Your current funds are $"<<*funds<<"."<<endl<<endl;
                    
                    cout<<"_____________________________________________________________________"<<endl<<endl;
                }
            }
            else if (ablChc == 'R'){
                if ((*(mercenaries + mrcChc - 1)).stats.stable == true){
                    cout<<(*(mercenaries + mrcChc - 1)).stats.name<<" is already mission ready."<<endl<<endl;
                    
                    cout<<"_____________________________________________________________________"<<endl<<endl;
                }
                else if (*funds < 100000){
                    cout<<"You have insufficient funds."<<endl<<endl;
                
                    cout<<"_____________________________________________________________________"<<endl<<endl;
                }
                else{
                    (*(mercenaries + mrcChc - 1)).stats.stable = true;
                    *funds = *funds - 100000;
                    cout<<(*(mercenaries + mrcChc - 1)).stats.name<<" has been resuscitated back to stable health."<<endl;
                    cout<<"Your current funds are $"<<*funds<<"."<<endl<<endl;
                    
                    cout<<"_____________________________________________________________________"<<endl<<endl;
                }
            }
            conChc = 'N';
        }
        
        cout<<"Would you like to improve the equipment of any of your mercenaries or resuscitate them?"<<endl;
        cout<<"{improving defensive equipment increases a mercenary's stats.defense and costs $20000 per mercenary)"<<endl;
        cout<<"(improving offensive equipment increases a mercenary's stats.attack and costs $50000 per mercenary)"<<endl;
        cout<<"(resuscitation changes a mercenary's status from injured to mission ready and costs $100000 per mercenary)"<<endl;
        cout<<"Please enter Y for yes, or anything else for no."<<endl;
        std::cin>>incChc;
        cout<<endl;
        
        cout<<"_____________________________________________________________________"<<endl<<endl;
    }
}

void Mercenary::chooseJob(int *funds, int *numMrc, bool *misRed, Mercenary *mercenaries){
    
    int jobChc;                                                                 //job to be chosen for mercenary team
    char conChc;                                                                //confirm choice of job
    char qitChc = 'Y';
    
    do{
        cout<<"Please choose from the list of available mercenary missions."<<endl;
        cout<<"(enter the number associated with the option from the list)"<<endl;
        cout<<"(entering any number not on the list will exit the job menu)"<<endl<<endl;

        cout<<"1) Escort Dignitary."<<endl;
        cout<<"Risk Factor: low"<<endl;
        cout<<"Payment: $20000."<<endl<<endl;

        cout<<"2) Apprehend Crime Lord."<<endl;
        cout<<"Risk Factor: medium"<<endl;
        cout<<"Payment: $100000."<<endl<<endl;

        cout<<"3) Infiltrate Foreign Military Complex."<<endl;
        cout<<"Risk Factor: high"<<endl;
        cout<<"Payment: $1000000."<<endl<<endl;

        std::cin>>jobChc;
        cout<<endl;


        while(jobChc > 0 && jobChc < 4){
            if(jobChc == 1){
                cout<<"Escort Dignitary: $20000"<<endl<<endl;
                cout<<"A wealthy dignitary is looking for security for hire."<<endl;
                cout<<"As he is valuable enough to be concerned with his safety,"<<endl;
                cout<<"but not in a governmental position to qualify for"<<endl;
                cout<<"formal military protection, he has turned to our"<<endl;
                cout<<"employers for assistance on the matter. Your job is"<<endl;
                cout<<"to escort the client to his destination unharmed. Our"<<endl;
                cout<<"intel has determined the risk factor of this mission to"<<endl;
                cout<<"be of a low rating, though some conflict may be likely."<<endl<<endl;

                cout<<"Would you like to take this job?"<<endl;
                cout<<"(please enter Y for yes, or anything else to decline)"<<endl;
                std::cin>>conChc;
                cout<<endl;

                if(conChc == 'Y'){
                    *misRed = false;                                                 //mission ready boolean
                    for(int count = 0; count < *numMrc; count++){
                        if ((*(mercenaries + count)).stats.stable == true)
                            *misRed = true;
                    }

                    if(*misRed == false)
                    cout<<"You have no mission ready mercenaries. You cannot accept any jobs at this time."<<endl<<endl;
                    else{
                        cout<<"_____________________________________________________________________"<<endl<<endl;
                        mercenaries->startJob1(funds, numMrc, misRed, mercenaries);
                    }
                }

                mercenaries->incAbl(funds, numMrc, mercenaries);
            }
            else if(jobChc == 2){
                cout<<"Apprehend Crime Lord: $100000"<<endl<<endl;
                cout<<"An organized crime lord has been under surveillance of"<<endl;
                cout<<"federal law enforcement for some time, but due to legal"<<endl;
                cout<<"constraints, they have not been able to get close enough"<<endl;
                cout<<"to him to expose his activity and try him for his crimes."<<endl;
                cout<<"This is where you come in. Your mission is to enter his"<<endl;
                cout<<"compound where you will find the necessary information to"<<endl;
                cout<<"expose and apprehend him. Our intel has determined the"<<endl;
                cout<<"risk factor for this mission to be of a moderate rating."<<endl;
                cout<<"As the compound is well guarded, conflict is more than likely."<<endl<<endl;

                cout<<"Would you like to take this job?"<<endl;
                cout<<"(please choose Y for yes, or anything else to decline)"<<endl;
                std::cin>>conChc;
                cout<<endl;

                if(conChc == 'Y'){
                    *misRed = false;                                                 //mission ready boolean
                    for(int count = 0; count < *numMrc; count++){
                        if ((*(mercenaries + count)).stats.stable == true)
                            *misRed = true;
                    }

                    if(*misRed == false)
                    cout<<"You have no mission ready mercenaries. You cannot accept any jobs at this time."<<endl<<endl;
                    else{
                        cout<<"_____________________________________________________________________"<<endl<<endl;
                        mercenaries->startJob2(funds, numMrc, misRed, mercenaries);
                    }
                }
                mercenaries->incAbl(funds, numMrc, mercenaries);
            }
            else if(jobChc == 3){
                cout<<"Infiltrate Foreign Military Complex: $1000000"<<endl<<endl;
                cout<<"Federal Intel has determined that a foreign military power"<<endl;
                cout<<"threatens the safety of the nation, but foreign policy"<<endl;
                cout<<"currently prohibits government forces from intervening."<<endl;
                cout<<"Our employers have been called upon to eliminate this threat."<<endl;
                cout<<"Your mission is to infiltrate the foreign military complex"<<endl;
                cout<<"in question and neutralize this threat. Our intel has"<<endl;
                cout<<"determined that the risk factor for this mission is high, due"<<endl;
                cout<<"to heavily armed military forces, making conflict almost certain."<<endl<<endl;

                cout<<"Would you like to take this job?"<<endl;
                cout<<"(please choose Y for yes, or anything else to decline)"<<endl;
                std::cin>>conChc;
                cout<<endl;

                if(conChc == 'Y'){
                    *misRed = false;                                                 //mission ready boolean
                    for(int count = 0; count < *numMrc; count++){
                        if ((*(mercenaries + count)).stats.stable == true)
                            *misRed = true;
                    }

                    if(*misRed == false)
                    cout<<"You have no mission ready mercenaries. You cannot accept any jobs at this time."<<endl<<endl;
                    else{
                        cout<<"_____________________________________________________________________"<<endl<<endl;
                        mercenaries->startJob3(funds, numMrc, misRed, mercenaries);
                    }
                }
                mercenaries->incAbl(funds, numMrc, mercenaries);
            }

            cout<<"Please choose from the list of available mercenary missions."<<endl;
            cout<<"(enter the number associated with the option from the list)"<<endl;
            cout<<"(entering a number not on the list will exit the job menu)"<<endl<<endl;

            cout<<"1) Escort Dignitary."<<endl;
            cout<<"Risk Factor: low"<<endl;
            cout<<"Payment: $20000."<<endl<<endl;

            cout<<"2) Apprehend Crime Lord."<<endl;
            cout<<"Risk Factor: medium"<<endl;
            cout<<"Payment: $100000."<<endl<<endl;

            cout<<"3) Infiltrate Foreign Military Complex."<<endl;
            cout<<"Risk Factor: high"<<endl;
            cout<<"Payment: $1000000."<<endl<<endl;

            std::cin>>jobChc;
            cout<<endl;
        }

        cout<<"Do you wish to exit the game?"<<endl;
        cout<<"(please enter Y for yes, or anything else to decline)"<<endl;
        std::cin>>qitChc;
        cout<<endl;

        cout<<"_____________________________________________________________________"<<endl<<endl;
    }while(qitChc != 'Y');
}

void Mercenary::startJob1(int *funds, int *numMrc, bool *misRed, Mercenary *mercenaries){
    
    cout<<"Job accepted. Engaging mission..."<<endl<<endl;
    
    unsigned seed = time(0);
    srand(seed);
    int numEnm;
    int mrcEng;
    int mrcHit;
    int enmHit;
    
    int enmAtk;
    int enmDfn;
    
    numEnm = 0 + rand() % 6;
    
    cout<<"Your mercenaries encounter "<<numEnm<<" hired thugs..."<<endl<<endl;
    
    std::cin.ignore();
    cout<<"(please press enter to continue)"<<endl;
    std::cin.get();
    cout<<endl;
    
    if(numEnm == 0){
        cout<<"The dignitary made it to his destination unharmed. Mission accomplished!"<<endl<<endl;
        *funds = *funds + 20000;
        cout<<"Your funds are now $"<<*funds<<"."<<endl<<endl;
    }
    
    while ((numEnm > 0) && (*misRed == true)){
        
        do{                                                                     //check to make sure mercenary engaged is not injured
            mrcEng = (0 + rand () % (*numMrc));
        }while((*(mercenaries + mrcEng)).stats.stable == false);
        enmAtk = 1 + rand () % 3;
        enmDfn = 1 + rand() % 10;
        cout<<"A hired thug stats.attacks "<<(*(mercenaries + mrcEng)).stats.name<<"!"<<endl;
        mrcHit = (0 + rand() % 4)*((*(mercenaries + mrcEng)).stats.attack);
        enmHit = (0 + rand() % 4)*(enmAtk);

        cout<<(*(mercenaries + mrcEng)).stats.name<<" deals "<<mrcHit<<" points of damage to the thug..."<<endl;
        cout<<"The thug deals "<<enmHit<<" points of damage to "<<(*(mercenaries + mrcEng)).stats.name<<"..."<<endl;
        if (mrcHit > enmDfn){
            numEnm = numEnm - 1;
            //(mercenaries + mrcEng)->useAbility(numEnm);
           
            cout<<(*(mercenaries + mrcEng)).stats.name<<" defeated the hired thug!"<<endl;
            (mercenaries + mrcEng)->useAbility(numEnm, mercenaries);
        }
        if (enmHit > (*(mercenaries + mrcEng)).stats.defense){
            (*(mercenaries + mrcEng)).stats.stable = false;
            cout<<(*(mercenaries + mrcEng)).stats.name<<" is now injured and won't be mission ready until resuscitated!"<<endl<<endl;
        }
        cout<<numEnm<<" thugs remain..."<<endl<<endl;
        cout<<"(please press enter to continue)"<<endl;
        std::cin.get();
        cout<<endl;
        
        *misRed = false;                                                         //mission ready boolean
        for(int count = 0; count < *numMrc; count++){
            if ((*(mercenaries + count)).stats.stable == true)
                *misRed = true;
        }
        if (*misRed == false && numEnm == 0){
            cout<<"All of the hired thugs have been defeated, but all of your mercenaries are injured."<<endl;
            cout<<"You have completed the mission and the dignitary made it to his destination unharmed,"<<endl;
            cout<<"but are unable to accept any other jobs until one of your mercenaries are resuscitated."<<endl<<endl;
            *funds = *funds + 20000;
            cout<<"Your funds are now $"<<*funds<<"."<<endl<<endl;
        }
        else if(*misRed == false)
            cout<<"All of your mercenaries are injured. You have failed the mission..."<<endl<<endl;
        else if(numEnm == 0){
            cout<<"All of the hired thugs have been defeated! The dignitary has made it"<<endl;
            cout<<"to his destination unharmed. Mission accomplished!"<<endl<<endl;
            *funds = *funds + 20000;
            cout<<"Your funds are now $"<<*funds<<"."<<endl<<endl;
        }
    }
    
    cout<<"(please press enter to continue)"<<endl;
    std::cin.get();
    cout<<endl;
    cout<<"_____________________________________________________________________"<<endl<<endl;
}

void Mercenary::startJob2(int *funds, int *numMrc, bool *misRed, Mercenary *mercenaries){
    
    cout<<"Job accepted. Engaging mission..."<<endl<<endl;
    
    unsigned seed = time(0);
    srand(seed);
    int numEnm;
    int mrcEng;
    int mrcHit;
    int enmHit;
    int enmAtk;
    int enmDfn;
    
    numEnm = 0 + rand() % 11;
    
    cout<<"Your mercenaries encounter "<<numEnm<<" compound guards..."<<endl<<endl;
    
    std::cin.ignore();
    cout<<"(please press enter to continue)"<<endl;
    std::cin.get();
    cout<<endl;
    
    if(numEnm == 0){
        cout<<"The crime lord has been apprehended along with the"<<endl;
        cout<<"evidence necessary for his incarceration. Mission accomplished!"<<endl<<endl;
        *funds = *funds + 50000;
        cout<<"Your funds are now $"<<*funds<<"."<<endl<<endl;
    }
    
    while ((numEnm > 0) && (*misRed == true)){
        
        do{                                                                     //check to make sure mercenary engaged is not injured
            mrcEng = (0 + rand () % (*numMrc));
        }while((*(mercenaries + mrcEng)).stats.stable == false);
        enmAtk = 1 + rand () % 5;
        enmDfn = 1 + rand() % 20;
        cout<<"A guard stats.attacks "<<(*(mercenaries + mrcEng)).stats.name<<"!"<<endl;
        mrcHit = (0 + rand() % 6)*((*(mercenaries + mrcEng)).stats.attack);
        enmHit = (0 + rand() % 6)*(enmAtk);
        
        //if (medAbl == true)

        cout<<(*(mercenaries + mrcEng)).stats.name<<" deals "<<mrcHit<<" points of damage to the guard..."<<endl;
        cout<<"The guard deals "<<enmHit<<" points of damage to "<<(*(mercenaries + mrcEng)).stats.name<<"..."<<endl;
        if (mrcHit > enmDfn){
            numEnm = numEnm - 1;
            cout<<(*(mercenaries + mrcEng)).stats.name<<" defeated the compound gaurd!"<<endl;
        }
        if (enmHit > (*(mercenaries + mrcEng)).stats.defense){
            (*(mercenaries + mrcEng)).stats.stable = false;
            cout<<(*(mercenaries + mrcEng)).stats.name<<" is now injured and won't be mission ready until resuscitated!"<<endl<<endl;
        }
        cout<<numEnm<<" guards remain..."<<endl<<endl;
        cout<<"(please press enter to continue)"<<endl;
        std::cin.get();
        cout<<endl;
        
        *misRed = false;                                                         //mission ready boolean
        for(int count = 0; count < *numMrc; count++){
            if ((*(mercenaries + count)).stats.stable == true)
                *misRed = true;
        }
        if (*misRed == false && numEnm == 0){
            cout<<"All of the compound guards have been defeated, but all of your mercenaries are injured."<<endl;
            cout<<"You have completed the mission and the crime lord has been apprehended along with the,"<<endl;
            cout<<"evidence necessary for his incarceration, but you are unable to accept any other jobs until"<<endl;
            cout<<"one of your mercenaries are resuscitated."<<endl<<endl;
            *funds = *funds + 50000;
            cout<<"Your funds are now $"<<*funds<<"."<<endl<<endl;
        }
        else if(*misRed == false)
            cout<<"All of your mercenaries are injured. You have failed the mission..."<<endl<<endl;
        else if(numEnm == 0){
            cout<<"All of the compound guards have been defeated! The crime lord has been apprehended"<<endl;
            cout<<"along with the evidence necessary for his incarceration. Mission accomplished!"<<endl<<endl;
            *funds = *funds + 50000;
            cout<<"Your funds are now $"<<*funds<<"."<<endl<<endl;
        }
    }
    
    cout<<"(please press enter to continue)"<<endl;
    std::cin.get();
    cout<<endl;
    cout<<"_____________________________________________________________________"<<endl<<endl;
}

void Mercenary::startJob3(int *funds, int *numMrc, bool *misRed, Mercenary *mercenaries){
    
    cout<<"Job accepted. Engaging mission..."<<endl<<endl;
    
    unsigned seed = time(0);
    srand(seed);
    int numEnm;
    int mrcEng;
    int mrcHit;
    int enmHit;
    int enmAtk;
    int enmDfn;
    
    numEnm = 0 + rand() % 21;
    
    cout<<"Your mercenaries encounter "<<numEnm<<" military soldiers..."<<endl<<endl;
    
    std::cin.ignore();
    cout<<"(please press enter to continue)"<<endl;
    std::cin.get();
    cout<<endl;
    
    if(numEnm == 0){
        cout<<"The military complex has been successfully infiltrated and"<<endl;
        cout<<"its threat has been neutralized. Mission accomplished!"<<endl<<endl;
        *funds = *funds + 100000;
        cout<<"Your funds are now $"<<*funds<<"."<<endl<<endl;
    }
    
    while ((numEnm > 0) && (*misRed == true)){
        
        do{                                                                     //check to make sure mercenary engaged is not injured
            mrcEng = (0 + rand () % (*numMrc));
        }while((*(mercenaries + mrcEng)).stats.stable == false);
        enmAtk = 1 + rand () % 10;
        enmDfn = 1 + rand() % 40;
        cout<<"A soldier stats.attacks "<<(*(mercenaries + mrcEng)).stats.name<<"!"<<endl;
        mrcHit = (0 + rand() % 11)*((*(mercenaries + mrcEng)).stats.attack);
        enmHit = (0 + rand() % 11)*(enmAtk);

        cout<<(*(mercenaries + mrcEng)).stats.name<<" deals "<<mrcHit<<" points of damage to the soldier..."<<endl;
        cout<<"The soldier deals "<<enmHit<<" points of damage to "<<mercenaries[mrcEng].stats.name<<"..."<<endl;
        if (mrcHit > enmDfn){
            numEnm = numEnm - 1;
            cout<<(*(mercenaries + mrcEng)).stats.name<<" defeated the military soldier!"<<endl;
        }
        if (enmHit > (*(mercenaries + mrcEng)).stats.defense){
            (*(mercenaries + mrcEng)).stats.stable = false;
            cout<<(*(mercenaries + mrcEng)).stats.name<<" is now injured and won't be mission ready until resuscitated!"<<endl<<endl;
        }
        cout<<numEnm<<" soldiers remain..."<<endl<<endl;
        cout<<"(please press enter to continue)"<<endl;
        std::cin.get();
        cout<<endl;
        
        *misRed = false;                                                         //mission ready boolean
        for(int count = 0; count < *numMrc; count++){
            if ((*(mercenaries + count)).stats.stable == true)
                *misRed = true;
        }
        if (*misRed == false && numEnm == 0){
            cout<<"All of the military soldiers have been defeated, but all of your mercenaries are injured."<<endl;
            cout<<"You have completed the mission and the military complex has been infiltrated and its threat has been"<<endl;
            cout<<"neutralized, but you are unable to accept any other jobs until one of your mercenaries are resuscitated."<<endl<<endl;
            *funds = *funds + 100000;
            cout<<"Your funds are now $"<<*funds<<"."<<endl<<endl;
        }
        else if(*misRed == false)
            cout<<"All of your mercenaries are injured. You have failed the mission..."<<endl<<endl;
        else if(numEnm == 0){
            cout<<"All of the military soldiers have been defeated! The military complex has been"<<endl;
            cout<<"successfully infiltrated and its threat has been neutralized. Mission accomplished!"<<endl<<endl;
            *funds = *funds + 100000;
            cout<<"Your funds are now $"<<*funds<<"."<<endl<<endl;
        }
    }
    
    cout<<"(please press enter to continue)"<<endl;
    std::cin.get();
    cout<<endl;
    cout<<"_____________________________________________________________________"<<endl<<endl;
}

void Mercenary::saveScore(int *funds, int *numMrc, Mercenary *mercenaries){
    
    char savChc = 'Y';
    const int SIZE = 3;
    char initials[SIZE] = {' ',' ',' '};
    int highScore = 0;
    
    std::fstream file;
    file.open("scores.txt", std::ios::out | std::ios::binary | std::ios::app);
    
    cout<<"Would you like to save your score?"<<endl;
    cout<<"(please enter Y for yes, or anything else to decline)"<<endl;
    
    std::cin>>savChc;
    cout<<endl;
    
    cout<<"_____________________________________________________________________"<<endl<<endl;
    
    if(savChc == 'Y'){
        cout<<"(please enter your initials to be saved with your high score)"<<endl;
        for(int count = 0; count < SIZE; count++)
            std::cin>>initials[count];
        
        cout<<"_____________________________________________________________________"<<endl<<endl;
    

        cout<<endl<<endl;


        for(int count = 0; count < *numMrc; count++){
            highScore = highScore + 20000*((*(mercenaries + count)).stats.defense - 5);
            highScore = highScore + 20000*((*(mercenaries + count)).stats.attack - 3);
            if ((*(mercenaries + count)).stats.stable == true)
                highScore = highScore + 20000;
        }

        highScore = highScore + *funds;

        file.write(initials, sizeof(initials));

        file.write(reinterpret_cast<char *>(&highScore), sizeof(highScore));

        cout<<endl<<endl;
    }
    
    file.close();
}

void changeStat(int option, Mercenary& merc){
	if(option == 1){
		merc.stats.attack = 12;
	}
	
	else if(option == 2){
		merc.stats.defense = 23;
	}
	
	else if(option == 3){
		merc.stats.stable = true;
	}
	
	else{}
}

Mercenary::Statistics Mercenary::getStats(){
	return stats;
}

