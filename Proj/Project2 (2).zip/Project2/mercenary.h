#ifndef Mercenary_H_
#define Mercenary_H_

#include <iostream>
#include <string>

using namespace std;

class Mercenary                                                                 //class of mercenaries
{
	
	protected:
                                         //function to set mercenary defense
                
            struct Statistics{                                                  //structure of mercenary stats
                    int attack;                                                 //mercenary attack
                    int defense;                                                //mercenary defense
                    bool stable;                                                //mercenary health status
                    std::string name;                                           //mercenary name
                    std::string type;                                           //mercenary type
            } stats;                                                            //structure variable
            
	public:

            static struct Army{                                                 //structure of mercenary types
                int numGren;                                                    //grenadier types
                int numMedic;                                                   //medic types
            }platoon;                                                           //structure variable

            bool abilityUsed;                                                   //boolean flag to determine of mercenary's special ability has been used on current battle

            Mercenary();                                                        //default constructor
            Mercenary(std::string);                                             //constructor
            Mercenary(int a, int b);                                            //constructor
            Mercenary(int a, int b, std::string n);                             //constructor
            Mercenary(int a, int b, std::string n, bool s);                     //constructor
           
            ~Mercenary();                                                       //destructor

            int getDefense();                                                   //function to calculate mercenary defense
            int getAttack();                                                    //function to calculate mercenary attack
            std::string getType();                                              //function to determine mercenary type
            std::string getName();                                              //function to determine mercenary name
            void display();       
			                                             //display mercenary stats
		void setAttack(int);                                            //function to set mercenary attack
		void setDefense(int);  	
			
            static Army amtMrc(int *, int *);                                   //function to determine amount of mercenaries
            void trainMrc(int *, int *, Mercenary *);                           //function to set base stats of mercenaries
            void incAbl(int *, int *, Mercenary *);                             //function to increase stats of mercenaries
            void chooseJob(int *, int *, bool *, Mercenary *);                  //function to choose job for mercenary group
            void startJob1(int *, int *, bool *, Mercenary *);                  //function to start job 1
            void startJob2(int *, int *, bool *, Mercenary *);                  //function to start job 2
            void startJob3(int *, int *, bool *, Mercenary *);                  //function to start job 3
            void saveScore(int *, int *, Mercenary *);                          //function to start score
            virtual bool useAbility(int&, Mercenary*) = 0;                          //virtual function to use mercenary's special ability
            friend void changeStat(int, Mercenary&);                            //function to change mercenary's stats
            Statistics getStats();
            //friend void abilities(Mercenary merc);		

	//protected:
};

//Mercenary::Army Mercenary::platoon = {0, 0};

#endif
