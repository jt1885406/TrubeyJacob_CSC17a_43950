
#include "Grenadier.h"

Grenadier::Grenadier(){
	stats.attack = 0;
	stats.defense = 0;
	stats.name = "merc";
        stats.type = "Grenadier";
	stats.stable = true;
}

Grenadier::Grenadier(std::string n){
	stats.attack = 0;
	stats.defense = 0;
	stats.name = n;
        stats.type = "Grenadier";
	stats.stable = true;
	abilityUsed = false;
}

Grenadier::Grenadier(int a, int b){
	stats.attack = a;
	stats.defense = b;
	stats.name = "merc";
        stats.type = "Grenadier";
	stats.stable = true;
}

Grenadier::Grenadier(int a, int b, std::string n){
	stats.attack = a;
	stats.defense = b;
	stats.name = n;
        stats.type = "Grenadier";
	stats.stable = true;
	
}

Grenadier::Grenadier(int a, int b, std::string n, bool s){
	stats.attack = a;
	stats.defense = b;
	stats.name = n;
        stats.type = "Grenadier";
	stats.stable = s;
}

bool Grenadier::useAbility(int &number, Mercenary* mercs){
	bool tempBool = abilityUsed;
	
        cout<< "Grenadier ability being used.." <<endl<<endl;
        
	if(abilityUsed == true){
		return false;
	}
	
	else{
		if(number == 1)
			number--;
		else
			number -= 2;
			
		abilityUsed = false;
	}

	return tempBool;
}

Grenadier::~Grenadier(){}
