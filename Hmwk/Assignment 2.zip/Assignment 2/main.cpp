/* 
 * File:   main.cpp
 * Author: Jacob Trubey
 * Purpose: mean, median, and mode problem and 5 additional problems from chapter 9
 * Created on March 16, 2015, 10:07 PM
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>

using namespace std;

//function prototypes 
void problem1();
void problem2();
void problem3();
void problem4();
void problem5();
void problem6();

float mean(int [], int, float);
float median(int [], int, float);
int *mode(int [], int);

int *fillArray(int);

void sortTests(float [], int);
float averageTests(float [], int);

void sortTests2(float [], int);
float averageTests2(float [], int);

void arrSelectSort(int *[], int);
void showArrPtr(int *[], int);
void showArray(const int [], int);

void arrSelectSort2(int *[], int);
void showArrPtr2(int *[], int);
void showArray2(const int [], int);

int main(){
    
    const short NUM_1 = 1,                                                      //number choices for menu of homework problems
                NUM_2 = 2,
                NUM_3 = 3,
                NUM_4 = 4,
                NUM_5 = 5,
                NUM_6 = 6,
                EXIT = 7;
    short choice;
    
    do{                                                                         //display menu menu option to user while exit choice has not been selected
        cout << "Homework Problems" << endl << endl
             << "1. Mean, Median, Mode problem" << endl
             << "2. Problem 9.1" << endl
             << "3. Problem 9.2" << endl
             << "4. Problem 9.3" << endl
             << "5. Problem 9.6" << endl
             << "6. Problem 9.7" << endl
             << "7. Exit" << endl << endl;
        do{                                                                     //ask user to enter menu option from list, with input validation that repeats process if valid choice has not been entered
            cout << "Please choose a homework problem to view by entering the corresponding number, or enter 7 to exit the program." << endl;
            cin >> choice;
            cout << endl;
        } while(choice < 1 || choice > 7);
        
        switch (choice)                                                         //switch menu that calls function corresponding to homework problem selected by user
        {
            case NUM_1:
                cout << "Mean, Median, Mode problem" << endl << endl;
                problem1();
                break;
                
            case NUM_2:
                cout << "Problem 9.1" << endl << endl;
                problem2();
                break;
                
            case NUM_3:
                cout << "Problem 9.2" << endl << endl;
                problem3();
                break;
                
            case NUM_4:
                cout << "Problem 9.3" << endl << endl;
                problem4();
                break;
                
            case NUM_5:
                cout << "Problem 9.6" << endl << endl;
                problem5();
                break;
                
            case NUM_6:
                cout << "Problem 9.7" << endl << endl;
                problem6();
                break;       
        }
        
    } while(choice != EXIT);
    
    return 0;
}

void problem1(){
    
    int *numberSet,                                                             //array of numbers
        setLength,                                                              //length of array to be entered by user
        number = 0,                                                             //interval at which numbers in array will repeat
        *modeValue;                                                             //value of mode(s) of array to be calculated
    float meanValue,                                                            //value of mean of array to be calculated
          medianValue;                                                          //value of median of array to be calculated
    
    do{                                                                         //allow user to enter length of array of 2 or greater
        cout << "Please enter the number of elements in the set, with a minimum entry of two elements." << endl;
        cin >> setLength;
        cout << endl;
        
    } while (setLength < 2);
    
    numberSet = new int[setLength];                                             //new operator used to dynamically allocate array, and data type (int) must match initially declared pointer
    
    for (int count = 0; count < setLength; count++){                            //assign number values to array sequentially, repeating values after every 10 elements assigned
        numberSet[count] = number;
        number++;
        if (number == 10)
            number = 0;       
    }
    
    for (int count = 0; count < setLength; count++){                            //display array
        cout << *(numberSet + count) << endl;
    }
    
    cout << endl;
    
    meanValue = mean(numberSet, setLength, meanValue);                          //call function to calculate mean
    
    cout << setprecision(2) << showpoint << fixed;                              //display mean
    cout << "the mean is: " << meanValue << endl << endl;
    
    medianValue = median(numberSet, setLength, medianValue);                    //call function to calculate median
    
    cout << setprecision(2) << showpoint << fixed;                              //display median
    cout << "the median is: " << medianValue << endl << endl;
    
    modeValue = mode(numberSet, setLength);                                     //call function to calculate the number of modes, maximum frequency, and value of the modes
    
    if (modeValue[1] > 1){                                                      //display number of modes, maximum frequency, and value of the modes
        cout << "The number of modes is: " << modeValue[0] << endl << endl;
        cout << "The maximum frequency is: " << modeValue[1] << endl << endl;
        cout << "The mode(s) is/are: " << endl;
    
        for (int count = 2; count < modeValue[0] + 2; count++)
            cout << modeValue[count] << endl;
    
        cout << endl;
    }
    else{
        cout << "The number of modes is: 0" << endl << endl;
        cout << "The maximum frequency is: 1" << endl << endl;
        cout << "There are no modes to display." << endl << endl;
    }       
    
    delete [] numberSet;                                                        //deallocate memory
    numberSet = 0;
}

float mean(int numberSet[], int setLength, float meanValue){
    
    int sum = 0;                                                                //sum of array elements added together
    
    for (int count = 0; count < setLength; count++){                            //calculate sum of array elements and assign to sum variable
        sum += numberSet[count];
    }
    
    meanValue = static_cast<float>(sum)/setLength;                              //calculate value of mean of array
    
    return meanValue;                                                           //return mean
}

float median(int numberSet[], int setLength, float medianValue){
    
    bool swap;                                                                  //sort array elements using bubble sort
    unsigned short temp;
    
    do
    {
        swap = false;
        for (int count = 0; count < (setLength - 1); count++)
        {
            if (numberSet[count] > numberSet[count + 1])
            {
                temp = numberSet[count];
                numberSet[count] = numberSet[count + 1];
                numberSet[count + 1] = temp;
                swap = true;
            }
        }
    } while (swap);
    
    for (int count = 0; count < setLength; count++){                            //display sorted array
        cout << *(numberSet + count) << endl;
    }
    
    cout << endl;
    
    if (setLength%2 == 0)                                                       //calculate median
        medianValue = static_cast<float>(numberSet[setLength/2] + numberSet[(setLength - 1)/2])/2;
    else
        medianValue = numberSet[setLength/2];
    
    return medianValue;                                                         //return median
    
}

int *mode(int numberSet[], int setLength){
    
    int *modePointer;                                                           //pointer to be dynamically allocated as array of modes
    unsigned short modalSize;                                                   //size of array of modes
    const unsigned short SIZE = 10;                                             //size constant for array of frequencies
    unsigned short i = 0;                                                       //element counter for array of frequencies
    int frequencyArray[SIZE] = {0},                                             //array of frequencies of numbers from number array
        frequencyValue = 1;                                                     //value of frequencies of numbers from number array
    
    if (setLength > 10){                                                        //assign frequency values to array of frequencies
        for (int count = 0; count <= setLength; count++){
            if (count == setLength)
            frequencyArray[i] = frequencyValue;
            else if (numberSet[count] == numberSet[count + 1])
                frequencyValue++;
            else{
                frequencyArray[i] = frequencyValue;
                i++;
                frequencyValue = 1;
            }
        }
    }
    else{
        for (int count = 0; count < setLength; count++){
            if (count == setLength)
            frequencyArray[i] = frequencyValue;
            else if (numberSet[count] == numberSet[count + 1])
                frequencyValue++;
            else{
                frequencyArray[i] = frequencyValue;
                i++;
                frequencyValue = 1;
            }
        }
    }
    
    
    cout << "the number value frequencies of the number set are:" << endl;      //display frequency array
    for (int count = 0; count < 10; count++)
        cout << frequencyArray[count] << endl;
    
    cout << endl;
    
    for (int count = 0; count < 10; count++){                                   //determine size of array of modes
        if (frequencyArray[count] != frequencyArray[count + 1]){
            modalSize = count + 3;
            count = 10;
        }
    }
    
    modePointer = new int[modalSize];                                           //dynamically allocate array of modes
    
    modePointer[0] = modalSize - 2;                                             //assign number of modes to first element of array of modes
    modePointer[1] = frequencyArray[modalSize - 3];                             //assign maximum frequency to second element of array of modes
    for (int count = 2; count < modalSize; count++)                             //assign values of modes to array of modes
        modePointer[count] = count - 2;
        
    /*for (int count = 0; count < 10; count++){
        if (frequencyArray[count] == frequencyArray[count + 1])
            cout << count << endl;
        else{
            modalSize = count + 3;
            cout << count << endl << endl;
            cout << "the number of modes is: " << count + 1 << endl << endl;
            cout << "the maximum frequency for the mode(s) is: " << frequencyArray[count] << endl << endl;
            count = 10;
        }
     */
        
        return modePointer;                                                     //return mode pointer
        
        delete [] modePointer;                                                  //deallocate memory
        modePointer = 0;
}


void problem2(){
    
    int *dynArray,                                                              //array to be dynamically allocated
        arrayLength;                                                            //size of array to be entered by user
    
    do{                                                                         //prompt user to enter size of array, with input validation of size greater than zero
        cout << "Please choose a size for the array. The size must be greater than zero." << endl;
        cin >> arrayLength;
        cout << endl;
    } while (arrayLength < 1);
            
    dynArray = fillArray(arrayLength);                                          //call function to dynamically allocate and fill array
    
    cout << "The elements for the array are: " << endl;
    
    for (int count = 0; count < arrayLength; count++){                          //display array
        cout << dynArray[count] << endl;
    }
    
    cout << endl;
    
    delete [] dynArray;                                                         //deallocate memory
    dynArray = 0;
}

int *fillArray(int arrayLength){
    
    int *dynArr;                                                                //array to be dynamically allocated and filled
    unsigned seed = time(0);                                                    //system time
    srand(seed);                                                                //randomized seed
    
    dynArr = new int[arrayLength];                                              //dynamically allocate array with size entered by user
    
    for (int count = 0; count < arrayLength; count++){                          //fill array with random numbers
        dynArr[count] = rand()%90 + 10;
    }
    
    return dynArr;                                                              //return dynamically allocated array
    
}

void problem3(){
    
    float *testScores,                                                          //array of test scores
          average;                                                              //average of test scores
    int   amountTests;                                                          //size of test score array
    
    do{                                                                         //prompt user to enter size of test score array, with input validation of size greater than zero
    cout << "Please enter the amount of test scores." << endl;
    cin >> amountTests;
    cout << endl;
    }while (amountTests < 1);
    
    testScores = new float[amountTests];                                        //dynamically allocate test score array
    
    cout << "Please enter the scores for each test." << endl;                   //prompt user to enter individual test scores into array with input validation of test scores between zero and one hundred
        for (int count = 0; count < amountTests; count++){
            cin >> testScores[count];
            while (testScores[count] < 0 || testScores[count] > 100){
                cout << "This is an invalid test score. Please reenter the test score with a valid entry." << endl;
                cin >> testScores[count];
            }
        }
    sortTests(testScores, amountTests);                                         //call function to sort tests
    
    average = averageTests(testScores, amountTests);                            //call function to average test scores
    
    cout << endl << "The test scores are:" << endl;
    
    for (int count = 0; count < amountTests; count++)                           //display test scores
        cout << testScores[count] << endl;
    
    cout << setprecision(1) << showpoint << fixed;                              //display average of test scores
    
    cout << endl << "The average of the test scores is: " << average << endl << endl;
    
    delete [] testScores;                                                       //deallocate memory
    testScores = 0;
    
}

void sortTests(float testScores[], int amountTests){
    
    bool swap;                                                                  //boolean condition for bubble sort
    float temp;                                                                 //temporary place holder for bubble sort
    
    do{                                                                         //sort test scores using bubble sort
        swap = false;
        for (int count = 0; count < (amountTests - 1); count++){
            if (testScores[count] > testScores[count + 1]){
                temp = testScores[count];
                testScores[count] = testScores[count + 1];
                testScores[count + 1] = temp;
                swap = true;
            }
        }      
    }while (swap);
}

float averageTests(float testScores[], int amountTests){
    
    float testsSum = 0,                                                         //sum of test scores
          testsAverage;                                                         //average of test scores
    
    for (int count = 0; count < amountTests; count ++)                          //calculate sum of test scores
        testsSum = testsSum + testScores[count];
    
    testsAverage = testsSum/amountTests;                                        //calculate average of test scores
    
    return testsAverage;                                                        //return average of test scores
}

void problem4(){
    
    float *testScores,                                                          //array of test scores
          average;                                                              //average of test scores
    int   amountTests;                                                          //size of test score array
    
    do{
    cout << "Please enter the amount of test scores." << endl;                  //prompt user to enter size of test score array, with input validation of size greater than zero
    cin >> amountTests;
    cout << endl;
    }while (amountTests < 1);
    
    testScores = new float[amountTests];                                        //dynamically allocate test score array
    
    cout << "Please enter the scores for each test." << endl;                   //prompt user to enter individual test scores into array with input validation of test scores between zero and one hundred
        for (int count = 0; count < amountTests; count++){
            cin >> testScores[count];
            while (testScores[count] < 0 || testScores[count] > 100){
                cout << "This is an invalid test score. Please reenter the test score with a valid entry." << endl;
                cin >> testScores[count];
            }
        }
    sortTests2(testScores, amountTests);                                        //call function to sort tests
    
    average = averageTests2(testScores, amountTests);                           //call function to drop lowest test score and average remaining scores
    
    cout << endl << "The test scores are:" << endl;
    
    for (int count = 0; count < amountTests; count++)                           //display test scores with lowest score included
        cout << testScores[count] << endl;
    
    cout << setprecision(1) << showpoint << fixed;                              //display average of test scores with lowest test score dropped
    
    cout << endl << "The average of the test scores with the lowest score dropped is: " << average << endl << endl;
    
    delete [] testScores;                                                       //deallocate memory
    testScores = 0;
    
}

void sortTests2(float testScores[], int amountTests){
    
    bool swap;                                                                  //boolean condition for bubble sort
    float temp;                                                                 //temporary place holder for bubble sort
    
    do{                                                                         //sort test scores using bubble sort
        swap = false;
        for (int count = 0; count < (amountTests - 1); count++){
            if (testScores[count] > testScores[count + 1]){
                temp = testScores[count];
                testScores[count] = testScores[count + 1];
                testScores[count + 1] = temp;
                swap = true;
            }
        }      
    }while (swap);
}

float averageTests2(float testScores[], int amountTests){
    
    float testsSum = 0,                                                         //sum of test scores
          testsAverage;                                                         //average of test scores
    
    for (int count = 1; count < amountTests; count++)                           //calculate sum of test scores, dropping lowest test score by starting count at one instead of zero
        testsSum = testsSum + testScores[count];
    
    testsAverage = testsSum/(amountTests - 1);                                  //calculate average of test scores with lowest test score dropped
    
    return testsAverage;                                                        //return average of test scores with lowest test score dropped
}

void problem5(){
    
    int *donations,                                                             //array of donations
        numDonations;                                                           //size of donations array
    
    do{                                                                         //prompt user to enter size of donations with input validation of size greater than zero
    cout << "Please enter the number of Donations." << endl;
    cin >> numDonations;
    cout << endl;
    }while (numDonations < 1);
    
    donations = new int[numDonations];                                          //dynamically allocate donations array
    
    cout << "Please enter the amount for each donation." << endl;               //prompt user to enter individual donation values with input validation of value greater than zero
    for (int count = 0; count < numDonations; count++){
        cin >> donations[count];
        while (donations[count] < 1){
            cout << "That is an invalid entry. Please enter a valid donation amount." << endl;
            cin >> donations[count];
        }
    }
    
    cout << endl;
    
    int *arrPtr[numDonations];                                                  //array for select sort of donations array
    
    for (int count = 0; count < numDonations; count++)                          //synchronize select sort array with donations array
        arrPtr[count] = &donations[count];
    
    arrSelectSort(arrPtr, numDonations);                                        //call function to sort select sort array in ascending order
    
    cout << "The donations, sorted in ascending order, are: \n";                //call function to display sorted select sort array
    showArrPtr(arrPtr, numDonations);
    
    cout << "The donations, in their original order, are: \n";                  //call function to display unsorted donations array
    showArray(donations, numDonations);
    
    delete [] donations;                                                        //deallocate memory
    donations = 0;
}

void arrSelectSort(int *arrPtr[], int numDonations){
    
    int startScan, minIndex;                                                    //sort array in ascending order using select sort
    int *minElem;
    
    for (startScan = 0; startScan < (numDonations - 1); startScan++){
        minIndex = startScan;
        minElem = arrPtr[startScan];
        for (int index = startScan + 1; index < numDonations; index++){
            if (*(arrPtr[index]) < *minElem)
            {
                minElem = arrPtr[index];
                minIndex = index;
            }
        }
        arrPtr[minIndex] = arrPtr[startScan];
        arrPtr[startScan] = minElem;
    }
}

void showArrPtr(int *arrPtr[], int numDonations){
    
    for (int count = 0; count < numDonations; count++)                          //display sorted select sort array
        cout << *(arrPtr[count]) << " ";
    cout << endl << endl;
}

void showArray(const int donations[], int numDonations){
    
    for (int count = 0; count < numDonations; count++)                          //display unsorted donations array
        cout << donations[count] << " ";
    cout << endl << endl;
}

void problem6(){
    
    int *donations,                                                             //array of donations
        numDonations;                                                           //size of donations array
    
    do{                                                                         //prompt user to enter size of donations with input validation of size greater than zero
    cout << "Please enter the number of Donations." << endl;
    cin >> numDonations;
    cout << endl;
    }while (numDonations < 1);
    
    donations = new int[numDonations];                                          //dynamically allocate donations array
    
    cout << "Please enter the amount for each donation." << endl;               //prompt user to enter individual donation values with input validation of value greater than zero
    for (int count = 0; count < numDonations; count++){
        cin >> donations[count];
        while (donations[count] < 1){
            cout << "That is an invalid entry. Please enter a valid donation amount." << endl;
            cin >> donations[count];
        }
    }
    
    cout << endl;
    
    int *arrPtr[numDonations];                                                  //array for select sort of donations array
    
    for (int count = 0; count < numDonations; count++)                          //synchronize select sort array with donations array
        arrPtr[count] = &donations[count];
    
    arrSelectSort2(arrPtr, numDonations);                                       //call function to sort select sort array in descending order
    
    cout << "The donations, sorted in descending order, are: \n";               //call function to display sorted select sort array
    showArrPtr2(arrPtr, numDonations);
    
    cout << "The donations, in their original order, are: \n";                  //call function to display unsorted donations array
    showArray2(donations, numDonations);
    
    delete [] donations;                                                        //deallocate memory
    donations = 0;
}

void arrSelectSort2(int *arrPtr[], int numDonations){
    
    int startScan, maxIndex;                                                    //sort array in descending order using select sort
    int *maxElem;
    
    for (startScan = 0; startScan < (numDonations - 1); startScan++){
        maxIndex = startScan;
        maxElem = arrPtr[startScan];
        for (int index = startScan + 1; index < numDonations; index++){
            if (*(arrPtr[index]) > *maxElem)
            {
                maxElem = arrPtr[index];
                maxIndex = index;
            }
        }
        arrPtr[maxIndex] = arrPtr[startScan];
        arrPtr[startScan] = maxElem;
    }
}

void showArrPtr2(int *arrPtr[], int numDonations){
    
    for (int count = 0; count < numDonations; count++)                          //display sorted select sort array
        cout << *(arrPtr[count]) << " ";
    cout << endl << endl;
}

void showArray2(const int donations[], int numDonations){
    
    for (int count = 0; count < numDonations; count++)                          //display unsorted donations array
        cout << donations[count] << " ";
    cout << endl << endl;
}