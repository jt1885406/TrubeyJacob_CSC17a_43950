#ifndef MOVIEDATA_H
#define	MOVIEDATA_H

struct MovieData
{
    std::string title;                                                       
    std::string director;                                                   
    int releaseYear;                                                         
    int runTime;                                                             
};

#endif	/* MOVIEDATA_H */

