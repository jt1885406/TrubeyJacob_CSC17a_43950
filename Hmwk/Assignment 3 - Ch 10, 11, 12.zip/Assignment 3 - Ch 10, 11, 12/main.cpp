/* 
 * File:   main.cpp
 * Author: Jacob Trubey
 * 
 * Created on March 29, 2015, 8:21 PM
 */

#include <cstdlib>                                                              
#include <ctime>                                                               
#include <cctype>                                                               
#include <cstring>                                                            
#include <string>                                                              
#include <iostream>                                                            
#include <iomanip>                                                             
#include <fstream>                                                             
#include <cmath>                                                                

#include "movieData.h"                                                          
#include "speakerBureau.h"                                                      
#include "softDrinks.h"                                                         
#include "company.h"                                                           
using namespace std;                                                           


void menu();                                                                    
int getN();                                                                     

void problem1();                                                                
void problem2();                                                                
void problem3();                                                              
void problem4();                                                               
void problem5();                                                               
void problem6();                                                               
void problem7();                                                               
void problem8();                                                                
void problem9();                                                               
void problem10();                                                               

int wordCount(char *);

int vowelCount(char *);
int consonantCount(char *);
char menuProb2();

void displayMovieInfo(MovieData&, MovieData&);                                  

void arrayToFile(string, int *, const int);
void fileToArray(string, int *, const int);

int main()
{
    const int PROB1 = 1, PROB2 = 2, PROB3 = 3, PROB4 = 4, PROB5 = 5,            
              PROB6 = 6, PROB7 = 7, PROB8 = 8, PROB9 = 9, PROB10 = 10,
              EXIT = 11;
    int inN;                                                                   
    
    do{                                                                        
        menu();                                                                
        inN = getN();                                                          
        switch(inN){
            case 1: problem1(); break;
            case 2: problem2(); break;
            case 3: problem3(); break;
            case 4: problem4(); break;
            case 5: problem5(); break;
            case 6: problem6(); break;
            case 7: problem7(); break;
            case 8: problem8(); break;
            case 9: problem9(); break;
            case 10: problem10(); break;
        }
        
        
    } while (inN != 11);                                                         
        
    return 0;
}
void menu()
{
    cout << "\n__________________________________________________________________________________________________________________\n\n";
    cout << "--------------------------\n";
    cout << "CSC 17a - Hmwk Problems\n"
            "-----------------------\n\n"
            "1.  Problem 10.4 (Average Number of Letters)\n"
            "2.  Problem 10.6 (Vowels and Consonants)\n"
            "3.  Problem 10.7 (Name Arranger)\n"
            "4.  Problem 11.1 (Movie Data)\n"
            "5.  Problem 11.9 (Speakers' Bureau)\n"
            "6.  Problem 11.13 (Drink Machine Simulator)\n"
            "7.  Problem 12.7 (Sentence Filter)\n"
            "8.  Problem 12.8 (Array/File Functions)\n"
            "9.  Problem 12.9 (File Encryption Filter)\n"
            "10. Problem 12.11 (Corporate Sales Data Output)\n"
            "11. Exit\n\n";
}
int getN()
{
    int num;
    
    do{
        cout << "Select a valid menu option: ";
        cin >> num;
    }while(num < 1 || num > 11);
    
    cout << "\n__________________________________________________________________________________________________________________\n\n";
    
    return num;
}
void problem1()
{
    
    const int SIZE = 500;
    char words[SIZE];                                                           
    int numWords, numLetters;                                                  
    int i = 0;                                                                  
    int numLetters1 = 0;                                                        
    float avgLetters;                                                          
    
    cin.ignore();
    cout << "Enter a phrase or short sentence.\n\n";
    cin.getline(words, SIZE);
    
    numWords = wordCount(words);                                               
    
   
    while (words[i] != '\0')
    {
        if (isalpha(words[i]))                                                 
            numLetters1++;
        i++;
    }
    
    avgLetters = static_cast<float>(numLetters1)/numWords;                    
                                                                               
    
                                                                               
                                                                               
    cout << endl;
    cout << "Number of Words: " << numWords << endl;
    cout << "Number of Letters: " << numLetters1 << endl;
    cout << setprecision(1) << fixed << showpoint;
    cout << "Average Number of Letters in Each Word: " << avgLetters << endl;
}

int wordCount(char *words)
{    
    int wordCount = 0;
    
    while (*words != '\0')
    {
        if (*words == ' ')
            wordCount++;            
        words++;
    }
    
    wordCount++;                                                               
                                                                               
                                                                               
    return wordCount;
}

void problem2()
{
    
    
    const int SIZE = 500;
    char words[SIZE];                                                         
    int numVowels, numConsonants;                                            
    char opt;                                                                  
    
    do
    {
        cin.ignore();
        cout << "\nEnter a phrase or short sentence.\n\n";
        cin.getline(words, SIZE);
    
        numVowels = vowelCount(words);                                        
        numConsonants = consonantCount(words);                                 
    
        opt = menuProb2();
        
        if (opt == 'A')
            cout << "Number of vowels: " << numVowels << endl;
        else if (opt == 'B')
            cout << "Number of consonants: " << numConsonants << endl;
        else if (opt == 'C')
            cout << "Number of vowels and consonants: " << numVowels + numConsonants << endl;
        else if (opt == 'D')
            cout << "";
        else
            cout << "\nYou entered E to exit the program.\n\n";
        
    } while (opt != 'E');
}

int vowelCount(char *w)
{
    int vowels = 0;                                                          
    
    while (*w != '\0')                                                         
    {
        if (isupper(*w))                                                    
            *w = tolower(*w);
        
        if (*w == 'a' || *w == 'e' || *w == 'i' || *w == 'o' || *w == 'u')     
            vowels++;
        
        *w++;                                                                  
    }
    
    return vowels;
}

int consonantCount(char *w)
{
    int consonants = 0;                                                        
    
    while (*w != '\0')                                                        
    {
        if (isupper(*w))                                                      
            *w = tolower(*w);
        
        if (*w != 'a' && *w != 'e' && *w != 'i' && *w != 'o' && *w != 'u' &&    
           isalpha(*w))                                                      
            consonants++;
        
        *w++;                                                                 
    }
    
    return consonants;
}

char menuProb2()
{
    char letter;                                                             
    cout << endl;
    cout << "\tMenu\n"
            "\t----\n\n"
            "A) Count the number of vowels in the string\n"
            "B) Count the number of consonants in the string\n"
            "C) Count both the vowels and consonants in the string\n"
            "D) Enter another string\n"
            "E) Exit the program\n\n";
    
    do
    {
        cout << "Select a valid menu option: ";
        cin >> letter;
        if (islower(letter))
            letter = toupper(letter);
    } while (letter < 65 || letter > 69);
    
    return letter;
}
void problem3()
{
    
    const int SIZE_1 = 40, SIZE_2 = 20, SIZE_3 = 20, SIZE_4 = 60;
    char firstN[SIZE_1], middleN[SIZE_2], lastN[SIZE_3], fullName[SIZE_4],
         space[] = " ", commaSpace[] = ", ";
    
    
    cin.ignore();
    cout << "Enter your first name: ";                                          
    cin.getline(firstN, SIZE_1);
    
    cout << "Enter your middle name: ";                                        
    cin.getline(middleN, SIZE_2);
    
    cout << "Enter your last name: ";                                         
    cin.getline(lastN, SIZE_3);
    
    if (islower(firstN[0]))                                                    
        firstN[0] = toupper(firstN[0]);
    
    if (islower(middleN[0]))                                                   
        middleN[0] = toupper(middleN[0]);
    
    if (islower(lastN[0]))                                                   
        lastN[0] = toupper(lastN[0]);
    
    strcat(firstN, space);                                                     
    
    if (sizeof(firstN) >= (strlen(firstN) + strlen(middleN) + 1))              
        strcat(firstN, middleN);
    else                                                                       
    {
        cout << "Your first name, middle name, or both, are too long! This program is limited to 19 characters\n"
                "for the first name and 19 characters for the middle name.\n";
        cout << "You entered " << strlen(firstN) << " letters for your first name.\n";
        cout << "You entered " << strlen(middleN) << " letters for your middle name.\n";
    }
    
    strcat(lastN, commaSpace);                                                 
    strcpy(fullName, lastN);                                                   
    
    if (sizeof(fullName) >= (strlen(firstN) + strlen(lastN) + 1))              
        strcat(fullName, firstN);                                               
    else                                                                       
    {
        cout << "Your last name is too long! This program is limited to 17 characters for the last name.\n";
        cout << "You entered " << strlen(lastN) - 2 << " letters for your last name.\n";
    }
    
    cout << "\nName: ";
    cout << fullName << endl;
}

void problem4()
{
   
    MovieData movie1, movie2;
    
    movie1.title = "Jurassic Park";
    movie1.director = "Steven Spielberg";
    movie1.releaseYear = 1993;
    movie1.runTime = 127;
    
    movie2.title = "American Psycho";
    movie2.director = "Mary Harron";
    movie2.releaseYear = 2000;
    movie2.runTime = 102;
    
    displayMovieInfo(movie1, movie2);
}

void displayMovieInfo(MovieData &m1, MovieData &m2)
{
    cout << "Movie Information:\n"
            "-----------------\n\n";
    cout << "Title: " << m1.title << endl;
    cout << "Director: " << m1.director << endl;
    cout << "Year Released: " << m1.releaseYear << endl;
    cout << "Running Time: " << m1.runTime << " min." << endl << endl;
    
    cout << "Title: " << m2.title << endl;
    cout << "Director: " << m2.director << endl;
    cout << "Year Released: " << m2.releaseYear << endl;
    cout << "Running Time: " << m2.runTime << " min." << endl << endl;
    
    cout << "Press enter to continue.";
    cin.ignore();
    cin.get();
    cout << endl << endl;
}

void problem5()
{
    const int SIZE = 10;
    SpeakerBureau speech[SIZE];
    
    int option;
    
    cout << "Enter the following information for each of the 10 speakers.\n\n";
    for (int count = 0; count < SIZE; count++)
    {
        cin.ignore();
        cout << "Speaker #" << count + 1 << ":\n";
        cout << "Name: ";
        getline(cin, speech[count].name);
        cout << "Telephone Number: ";
        getline(cin, speech[count].number);
        cout << "Speaking Topic: ";
        getline(cin, speech[count].topic);
        do
        {
            cout << "Fee Required: ";
            cin >> speech[count].fee;
            if (speech[count].fee < 0)
                cout << "You must enter a fee greater than $0.00.\n";
        } while (speech[count].fee < 0);
        cout << endl;
    }
    
    cout << "\tSpeakers' Bureau\n"
            "\t----------------\n\n";
    for (int count = 0; count < SIZE; count++)
    {
        cout << "Speaker #" << count + 1 << ":\n";
        cout << "Name: " << speech[count].name << endl;
        cout << "Telephone Number: " << speech[count].number << endl;
        cout << "Speaking Topic: " << speech[count].topic << endl;
        cout << setprecision(2) << showpoint << fixed;
        cout << "Fee Required: $ " << speech[count].fee << endl << endl;
    }
    
    do
    {
    
        do
        {
            cout << "There are 10 speakers currently listed in the speakers' bureau. To edit any of the speakers' information\n"
                    "enter a number between 1 and 10, corresponding with a specific speaker. To finish editing enter 0. ";
            cin >> option;
        } while (option < 0 || option > 10);
        
        cout << endl;
        
        if (option == 1)
        {
            cin.ignore();
            cout << "Speaker #1:\n";
            cout << "Name: ";
            getline(cin, speech[0].name);
            cout << "Telephone Number: ";
            getline(cin, speech[0].number);
            cout << "Speaking Topic: ";
            getline(cin, speech[0].topic);
            do
            {
                cout << "Fee Required: ";
                cin >> speech[0].fee;
                if (speech[0].fee < 0)
                    cout << "You must enter a fee greater than $0.00.\n";
            } while (speech[0].fee < 0);
        }
        else if (option == 2)
        {
            cin.ignore();
            cout << "Speaker #2:\n";
            cout << "Name: ";
            getline(cin, speech[1].name);
            cout << "Telephone Number: ";
            getline(cin, speech[1].number);
            cout << "Speaking Topic: ";
            getline(cin, speech[1].topic);
            do
            {
                cout << "Fee Required: ";
                cin >> speech[1].fee;
                if (speech[1].fee < 0)
                    cout << "You must enter a fee greater than $0.00.\n";
            } while (speech[1].fee < 0);
        }
        else if (option == 3)
        {
            cin.ignore();
            cout << "Speaker #3:\n";
            cout << "Name: ";
            getline(cin, speech[2].name);
            cout << "Telephone Number: ";
            getline(cin, speech[2].number);
            cout << "Speaking Topic: ";
            getline(cin, speech[2].topic);
            do
            {
                cout << "Fee Required: ";
                cin >> speech[2].fee;
                if (speech[2].fee < 0)
                    cout << "You must enter a fee greater than $0.00.\n";
            } while (speech[2].fee < 0);
        }
        else if (option == 4)
        {
            cin.ignore();
            cout << "Speaker #4:\n";
            cout << "Name: ";
            getline(cin, speech[3].name);
            cout << "Telephone Number: ";
            getline(cin, speech[3].number);
            cout << "Speaking Topic: ";
            getline(cin, speech[3].topic);
            do
            {
                cout << "Fee Required: ";
                cin >> speech[3].fee;
                if (speech[3].fee < 0)
                    cout << "You must enter a fee greater than $0.00.\n";
            } while (speech[3].fee < 0);
        }
        else if (option == 5)
        {
            cin.ignore();
            cout << "Speaker #5:\n";
            cout << "Name: ";
            getline(cin, speech[4].name);
            cout << "Telephone Number: ";
            getline(cin, speech[4].number);
            cout << "Speaking Topic: ";
            getline(cin, speech[4].topic);
            do
            {
                cout << "Fee Required: ";
                cin >> speech[4].fee;
                if (speech[4].fee < 0)
                    cout << "You must enter a fee greater than $0.00.\n";
            } while (speech[4].fee < 0);
        }
        else if (option == 6)
        {
            cin.ignore();
            cout << "Speaker #6:\n";
            cout << "Name: ";
            getline(cin, speech[5].name);
            cout << "Telephone Number: ";
            getline(cin, speech[5].number);
            cout << "Speaking Topic: ";
            getline(cin, speech[5].topic);
            do
            {
                cout << "Fee Required: ";
                cin >> speech[5].fee;
                if (speech[5].fee < 0)
                    cout << "You must enter a fee greater than $0.00.\n";
            } while (speech[5].fee < 0);
        }
        else if (option == 7)
        {
            cin.ignore();
            cout << "Speaker #7:\n";
            cout << "Name: ";
            getline(cin, speech[6].name);
            cout << "Telephone Number: ";
            getline(cin, speech[6].number);
            cout << "Speaking Topic: ";
            getline(cin, speech[6].topic);
            do
            {
                cout << "Fee Required: ";
                cin >> speech[6].fee;
                if (speech[6].fee < 0)
                    cout << "You must enter a fee greater than $0.00.\n";
            } while (speech[6].fee < 0);
        }
        else if (option == 8)
        {
            cin.ignore();
            cout << "Speaker #8:\n";
            cout << "Name: ";
            getline(cin, speech[7].name);
            cout << "Telephone Number: ";
            getline(cin, speech[7].number);
            cout << "Speaking Topic: ";
            getline(cin, speech[7].topic);
            do
            {
                cout << "Fee Required: ";
                cin >> speech[7].fee;
                if (speech[7].fee < 0)
                    cout << "You must enter a fee greater than $0.00.\n";
            } while (speech[7].fee < 0);
        }
        else if (option == 9)
        {
            cin.ignore();
            cout << "Speaker #9:\n";
            cout << "Name: ";
            getline(cin, speech[8].name);
            cout << "Telephone Number: ";
            getline(cin, speech[8].number);
            cout << "Speaking Topic: ";
            getline(cin, speech[8].topic);
            do
            {
                cout << "Fee Required: ";
                cin >> speech[8].fee;
                if (speech[8].fee < 0)
                    cout << "You must enter a fee greater than $0.00.\n";
            } while (speech[8].fee < 0);
        }
        else if (option == 10)
        {
            cin.ignore();
            cout << "Speaker #10:\n";
            cout << "Name: ";
            getline(cin, speech[9].name);
            cout << "Telephone Number: ";
            getline(cin, speech[9].number);
            cout << "Speaking Topic: ";
            getline(cin, speech[9].topic);
            do
            {
                cout << "Fee Required: ";
                cin >> speech[9].fee;
                if (speech[9].fee < 0)
                    cout << "You must enter a fee greater than $0.00.\n";
            } while (speech[9].fee < 0);
        }
        
        cout << endl;
    } while (option != 0);
    
    cout << "\tSpeakers' Bureau\n"
            "\t----------------\n\n";
    for (int count = 0; count < SIZE; count++)
    {
        cout << "Speaker #" << count + 1 << ":\n";
        cout << "Name: " << speech[count].name << endl;
        cout << "Telephone Number: " << speech[count].number << endl;
        cout << "Speaking Topic: " << speech[count].topic << endl;
        cout << setprecision(2) << showpoint << fixed;
        cout << "Fee Required: $ " << speech[count].fee << endl << endl;
    }
    cout << "Press enter to continue.";
    cin.ignore();
    cin.get();
}

void problem6()
{
    
    SoftDrinks drinks[5];                                                   
    int option;                                                            
    int amount;                                                              
    int change;                                                             
    bool soldOut = true;                                                      
    int total = 0;                                                            
    
    drinks[0].drinkName = "Cola";
    drinks[0].drinkCost = 75;
    drinks[0].numDrinks = 20;
    
    drinks[1].drinkName = "Root Beer";
    drinks[1].drinkCost = 75;
    drinks[1].numDrinks = 20;
    
    drinks[2].drinkName = "Lemon-Lime";
    drinks[2].drinkCost = 75;
    drinks[2].numDrinks = 20;
    
    drinks[3].drinkName = "Grape Soda";
    drinks[3].drinkCost = 80;
    drinks[3].numDrinks = 20;
    
    drinks[4].drinkName = "Cream Soda";
    drinks[4].drinkCost = 80;
    drinks[4].numDrinks = 20;
    
    do
    {
        cout << "\tDRINKS\n"
                "\t------\n\n";
        cout << "1. Cola: " << right << setw(15) << "$0.75\n";
        cout << "2. Root Beer: " << right << setw(10) << "$0.75\n";
        cout << "3. Lemon-Lime: " << right << setw(9) << "$0.75\n";
        cout << "4. Grape Soda: " << right << setw(9) << "$0.80\n";
        cout << "5. Cream Soda: " << right << setw(9) << "$0.80\n";
        cout << "6. Exit\n\n";
        cout << "Choose an ice-cold, refreshing soft drink! (Or enter 6 to exit.) ";
        cin >> option;
        
        if (option != 6)
        {
            cout << "\nThis machine accepts at most $1.00 bills. When entering an amount do not enter any decimal points.\n"
                    "For example: To insert 75 cents, enter 75 or To insert 1 dollar, enter 100\n\n";
        }
        
        
        if (option == 1 && drinks[0].numDrinks > 0)
        {
            do
            {
                cout << "Enter an amount of money to be inserted into the drink machine: ";
                cin >> amount;
                if (amount < 75 || amount > 100)
                    cout << "Invalid amount.\n";
            } while (amount < 75 || amount > 100);
            
            drinks[0].numDrinks--;
            soldOut = false;                                                    
        }
        else if (option == 2 && drinks[1].numDrinks > 0)
        {
            do
            {
                cout << "Enter an amount of money to be inserted into the drink machine: ";
                cin >> amount;
                if (amount < 75 || amount > 100)
                    cout << "Invalid amount.\n";
            } while (amount < 75 || amount > 100);
            
            drinks[1].numDrinks--;
            soldOut = false;                                                  
        }
        else if (option == 3 && drinks[2].numDrinks > 0)
        {
            do
            {
                cout << "Enter an amount of money to be inserted into the drink machine: ";
                cin >> amount;
                if (amount < 75 || amount > 100)
                    cout << "Invalid amount.\n";
            } while (amount < 75 || amount > 100);
            
            drinks[2].numDrinks--;
            soldOut = false;                                                 
        }
        else if (option == 4 && drinks[3].numDrinks > 0)
        {
            do
            {
                cout << "Enter an amount of money to be inserted into the drink machine: ";
                cin >> amount;
                if (amount < 80 || amount > 100)
                    cout << "Invalid amount.\n";
            } while (amount < 80 || amount > 100);
            
            drinks[3].numDrinks--;
            soldOut = false;                                               
        }
        else if (option == 5 && drinks[4].numDrinks > 0)
        {
            do
            {
                cout << "Enter an amount of money to be inserted into the drink machine: ";
                cin >> amount;
                if (amount < 80 || amount > 100)
                    cout << "Invalid amount.\n";
            } while (amount < 80 || amount > 100);
            
            drinks[4].numDrinks--;
            soldOut = false;                                             
        }
        else if (option != 6)
        {
            cout << "Sold Out\n\n";
            cout << "Press enter to continue.";
            cin.ignore();
            cin.get();
            cout << endl << endl;
        }
        
        if (option == 1 || option == 2 || option == 3)
        {
            change = amount - 75;
            total += 75;                                                  
        }
        else if (option == 4 || option == 5)
        {
            change = amount - 80;
            total += 80;                                                    
        }
        
        if (soldOut == false)
        {
            cout << setprecision(2) << showpoint << fixed;
            cout << "\nAmount of Change: " << change/100.0 << " cents" << endl << endl;
        }
        
    } while (option != 6);
    
    cout << setprecision(2) << showpoint << fixed;
    cout << "Total Earnings: $ " << total/100.0 << endl << endl;
}

void problem7()
{
    string fileI;                                                               
    string fileO;                                                               
    fstream file1;
    fstream file2;
    char ch;
    
    cout << "Enter the first file name. This first file will be opened for input, and the input will be modified.\n";
    cin >> fileI;
    cout << "\nEnter the second file name. The modified input from file 1 will be written to this second file.\n";
    cin >> fileO;
    
    cout << endl;
    file1.open(fileI.c_str(), ios::in);
    file2.open(fileO.c_str(), ios::out);
    
    file1.get(ch);
    ch = toupper(ch);
    file2.put(ch);
    cout << ch << " ";
    int index = 0;
    do
    {
        if (index > 0)
        {
            file1.get(ch);
            file1.get(ch);
            if (ch == 10)
                file1.get(ch);
            
            ch = toupper(ch);
            file2.put(ch);
            cout << ch;
        }
        do
        {
            file1.get(ch);
            ch = tolower(ch);
            file2.put(ch);
            cout << ch;
        } while (ch != '.');
        cout << " ";
        index++;
    } while (file1);
    
    file1.close();
    file2.close();
    
    cout << endl << endl;
}

void problem8()
{
    
    int *ptr;
    const int SIZE = 5;
    string fileName = "arrayContents";
    
    arrayToFile(fileName, ptr, SIZE);
    fileToArray(fileName, ptr, SIZE);
    
    
}

void arrayToFile(string name, int *p, const int SIZE)
{
    int arr[SIZE];
    p = arr;
    
    for (int count = 0; count < SIZE; count++)
        arr[count] = count;
    
    fstream file;
    file.open(name.c_str(), ios::out | ios::binary);
    cout << "Writing data to file.\n";
    cout << "Done. Press enter to continue.";
    cin.ignore();
    cin.get();
    file.write(reinterpret_cast<char *>(arr), sizeof(arr));
    file.close();
}

void fileToArray(string name, int *p, const int SIZE)
{
    int arr[SIZE];
    p = arr;
    
    fstream file;
    file.open(name.c_str(), ios::in | ios::binary);
    cout << "Now reading data back into memory.\n";
    cout << "Done. Press enter to view file contents.";
    cin.get();
    file.read(reinterpret_cast<char *>(arr), sizeof(arr));
    file.close();
    
    cout << endl;
    for (int count = 0; count < SIZE; count++)
        cout << arr[count] << " ";
    
    cout << endl << endl;
}

void problem9()
{
    
    fstream file, mod_file;
    string name1;
    char ch, opt;
    
    cout << "Enter the name of the file to be encrypted: ";
    cin >> name1;
    cout << "The data in " << name1 << " will be encrypted and then stored in a file named \"Encryption.txt\"\n\n";
    file.open(name1.c_str(), ios::in);
    mod_file.open("Encryption.txt", ios::out);
    do
    {
        file.get(ch);                                                       
        ch += 10;                                                            
        mod_file.put(ch);                                                    
    } while (file);

    file.close();
    mod_file.close();
    
    cout << "File encryption complete.\n";
    
    cout << "Would you like to view both the non-encrypted and encrypted files? Enter Y/N: ";
    cin >> ch;
    cout << endl;
    
    if (ch == 'Y' || ch == 'y')
    {
        file.open(name1.c_str(), ios::in);
        mod_file.open("Encryption.txt", ios::in);
        
        cout << "Original File:\n";
        do
        {
            file.get(ch);
            cout << ch;
        } while (file);
        
        cout << endl << endl;
        cout << "Encrypted File:\n";
        do
        {
            mod_file.get(ch);
            cout << ch;
        } while (mod_file);
        
        file.close();
        mod_file.close();
    }
}

void problem10()
{
    
    Company data;
    char ch;
    
    fstream information("info.dat", ios::out | ios:: binary);
    
    do
    {
        cout << "Enter the following information about corporate sales.\n\n";
        cout << "Division: ";
        cin.ignore();
        cin.getline(data.division, 10);
        cout << "Enter the quarter: ";
        cin >> data.quarter;
        cout << "Enter the sales for each quarter:\n";
        cout << "Quarter 1: ";
        cin >> data.sales[0];
        cout << "Quarter 2: ";
        cin >> data.sales[1];
        cout << "Quarter 3: ";
        cin >> data.sales[2];
        cout << "Quarter 4: ";
        cin >> data.sales[3];
        
        information.write(reinterpret_cast<char *>(&data), sizeof(data));

        cout << "Would you like to enter information about another division of\n"
                "the company? Enter Y/N: ";
        cin >> ch;
        
    } while (ch == 'Y' || ch == 'y');
    
    information.close();
}