#ifndef COMPANY_H
#define	COMPANY_H

struct Company
{
    char division[10];                                                      
    char quarter;                                                            
    float sales[4];                                                           
};

#endif	/* COMPANY_H */

