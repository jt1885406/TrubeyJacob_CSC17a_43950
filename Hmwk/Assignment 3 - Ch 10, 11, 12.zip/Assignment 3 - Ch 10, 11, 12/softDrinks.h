#ifndef SOFTDRINKS_H
#define	SOFTDRINKS_H

struct SoftDrinks
{
    std::string drinkName;                                                  
    int drinkCost;                                                             
    int numDrinks;                                                         
};

#endif	/* SOFTDRINKS_H */

