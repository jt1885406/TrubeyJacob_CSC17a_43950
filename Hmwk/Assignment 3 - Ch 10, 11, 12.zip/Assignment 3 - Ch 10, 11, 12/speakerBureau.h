#ifndef SPEAKERBUREAU_H
#define	SPEAKERBUREAU_H

struct SpeakerBureau
{
    std::string name;                                                       
    std::string number;                                                       
    std::string topic;                                                         
    float fee;                                                          
};

#endif	/* SPEAKERBUREAU_H */

