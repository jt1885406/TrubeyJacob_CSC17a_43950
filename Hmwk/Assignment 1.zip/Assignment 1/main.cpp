/* 
 * File:    main.cpp
 * Author:  Jacob Trubey
 * Purpose: chapters 3-8, homework assignment 1
 * Created on March 13, 2015, 4:37 PM
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <fstream>

using namespace std;

/*
 * 
 */

//Function Prototypes
void problem1();
void problem2();
void problem3();
void problem4();
void problem5();
void problem6();
void problem7();

void celcius(float, float);

int main()
{
    const short NUM_1 = 1,                                                      // user menu choice options
                NUM_2 = 2,
                NUM_3 = 3,
                NUM_4 = 4,
                NUM_5 = 5,
                NUM_6 = 6,
                NUM_7 = 7,
                EXIT = 8;
    short choice;
    
    do
    {
        cout << "Homework Problems\n\n"                                         // display menu
             << "1. Problem 3.12\n"
             << "2. Problem 3.13\n"
             << "3. Problem 4.10\n"
             << "4. Problem 5.11\n"
             << "5. Problem 6.7\n"
             << "6. Problem 7.6\n"
             << "7. Problem 8.7\n"   
             << "8. Exit Program.\n\n";
        do                                                                      // prompt user to enter menu choice
        {
            cout << "Please choose a homework problem to view by entering the corresponding number, or enter 8 to exit the program.\n";
            cin >> choice;
            cout << endl;
        } while (choice < 1 || choice > 8);
    
        switch (choice)                                                         // redirect to homework problem chosen by user
        {
            case NUM_1:
                cout << "\nProblem 3.12.\n\n";
                problem1();
                break;
            
            case NUM_2:
                cout << "\nProblem 3.13.\n\n";
                problem2();
                break;
            
            case NUM_3:
                cout << "\nProblem 4.10.\n\n";
                problem3();
                break;
                
            case NUM_4:
                cout << "\nProblem 5.11.\n\n";
                problem4();
                break;
            
            case NUM_5:
                cout << "\nProblem 6.7.\n\n";
                problem5();
                break;
            
            case NUM_6:
                cout << "\nProblem 7.6.\n\n";
                problem6();
                break;
                
            case NUM_7:
                cout << "\nProblem 8.7.\n\n";
                problem7();
                break;
        
        }
    
    } while (choice != EXIT);                                                   // exit program

    return 0;
}


void problem1()
{
    /*
    This program calculates a monthly sales tax report, based on month,
    year, and total income entered by user, given state and county sales tax
    percentages.
    */
    
        //declare variables for month, year, total income, sales, county tax, state tax, and total tax.
    string month;
    unsigned short year;
    float totalIncome, productSales, countyTax, stateTax, totalTax;
    
    //Prompt user to enter month, year, and total income
    cout << "To calculate monthly sales tax report,\n"
         << "please first enter the month, then the year,\n"
         << "then the total income, separated by spaces.\n\n";
    
    //collect data
    cin >> month >> year >> totalIncome;
    
    //calculate sales without state and county tax: 1*sales + 0.4*sales + 0.2*sales = total
    productSales = totalIncome/1.06;
    
    //calculate county tax
    countyTax = 0.02 * productSales;
    
    //calculate state tax
    stateTax = 0.04 * productSales;
    
    //calculate total tax: (county + state tax)
    totalTax = countyTax + stateTax;
    
    //display monthly sales tax report to user
    cout << endl << "Month: " << month << endl;
    cout << "Year: " << year << endl;
    cout << "--------------------" << endl;
    cout << setprecision(2) << fixed;
    cout << setw(20) << left << "Total Collected:" << left << "$ " << totalIncome << endl;
    cout << setw(20) << left << "Sales:" << left << "$ " << productSales << endl;
    cout << setw(20) << left << "County Sales Tax:" << left << "$ " << countyTax << endl;
    cout << setw(20) << left << "State Sales Tax:" << left << "$ " << stateTax << endl;
    cout << setw(20) << left << "Total Sales Tax:" << left << "$ " << totalTax << endl;
}

void problem2()
{
    /*
    This program calculates the assessment value for a property and the
    associated property tax.
    */
    
    float actualValue, assessValue, propTax;
    
    cout << "To calculate the assessment value and property tax, please enter the actual value of the property.\n\n$ ";     // ask user to enter actual value
    cin >> actualValue;
    
    assessValue = 0.6*actualValue;                                                                                          // calculate assessment value
    
    propTax = 0.0064*assessValue;                                                                                           // calculate property tax
    
    cout << setprecision(2) << fixed;                                                                                       // display results
    cout << endl << endl << left << setw(20) << "Assessment Value:" << "$ " << assessValue << endl;
    cout << left << setw(20) << "Property Tax:" << "$ " << propTax << endl;
}

void problem3()
{
    /*
     This program calculates sale prices of a product depending on amount sold.
     */
    short amount;
    float totCost;
    
    cout << "Please enter the amount of units sold to determine sale price, if any.\n\n";   // ask user for amount sold.
    cin >> amount;

    if (amount <= 0)
        cout << "\n\n" << amount << " is not a valid input.\n";                             // input validation
    else
    {
        if (amount > 0 && amount < 10)                                                      // calculate sale price
            totCost = amount*99;
        else if (amount >= 10 && amount <= 19)
            totCost = 0.8*amount*99;
        else if (amount >= 20 && amount <= 49)
            totCost = 0.7*amount*99;
        else if (amount >= 50 && amount <= 99)
            totCost = 0.6*amount*99;
        else if (amount >= 100)
            totCost = 0.5*amount*99;
        
        cout << setprecision(2) << fixed;                                                   // display result
        cout << endl << "Total Cost: $ " << totCost << endl;
    }
}

void problem4()
{
    
    /*
     This program predicts the size of a population of organisms.
     */
    
    int numDays, population;
    float growthRate;
    
    do {
        cout << "Enter the initial population. It must be greater than or equal to\n"       // prompt user to enter initial population
                "2 organisms.\n";
        cin >> population;
    } while (population < 2);
    
    do {
        cout << "Enter a whole number between 1 and 100 for the percentage growth rate\n"   // prompt user to enter growth rate
                "of the organisms.\n";
        cin >> growthRate;
    } while (growthRate <= 0);
    
    do {
        cout << "Enter the number of days the population will multiply. It must be\n"       // prompt user to enter number of days to calculate
                "multiplying for 1 or more days.\n";
        cin >> numDays;
    } while (numDays < 1);
    
    growthRate = growthRate/100;                                                            // convert growth rate to percentage 
    
    cout << endl << endl;
    
    for (int count = 0; count < numDays; count++) {                                         // calculate new population and display results
        
        population = population + (population)*growthRate;
        
        cout << "Day " << count + 1 << ": " << population << endl;
    }
}

void problem5()
{
    
    /*
     This program converts the fahrenheit to celcius for the fahrenheit temperatures of 0-20.
     */
    
    float fahr, celc, result;
    
    cout << "Fahrenheit \t Celsius" << endl;
    cout << "------------------------" << endl << endl;
    
    for (fahr = 0; fahr <= 20; fahr++){
        
        celcius(fahr, celc);                                                                // call conversion function
    }
    
    cout << "------------------------" << endl;
}

void celcius(float fahr, float celc){
    
    celc = static_cast<float>(5)/9*(fahr-32);                                               // convert temperatures and display results
    
    cout << fahr << " \t\t " << setprecision(2) << fixed << showpoint << celc << endl;
}

void problem6()
{ 
    /*
     This program will open a file entered by the user and use loops to sum the values from the file, average those values,
     locate the highest value, and locate the lowest value.
     */
    
    ifstream inputFile;                                              // input file stream
    string filename;                                                 // file name entered by user
    const unsigned short SIZE = 100;                                 // default array size
    int fileContents[SIZE];                                          // array for file contents
    int count = 0;                                                   // number of values from file
    int total = 0;                                                   // sum of values
    float average;                                                   // average of values
    int highest;                                                     // highest value
    int lowest;                                                      // lowest value
    
    cout << "Please enter the filename: ";                           // ask user for file name
    cin >> filename;
    cout << endl;
    
    inputFile.open(filename.c_str());                                // open file
    
    while (count < SIZE && inputFile >> fileContents[count])         // count amount of values entered from file, and determine amount of elements needed for array
        count++;
    
    inputFile.close();                                               // close file
    
    cout << "The contents of the file are: ";                        // display contents of file
    for (int index = 0; index < count; index++)
        cout << fileContents[index] << " ";
    cout << endl << endl;
    
    for (int index = 0; index < count; index++)                      // sum values of file
        total += fileContents[index];
    
    average = total / count;                                         // average values of file
    
    highest = fileContents[0];                                       // locate highest value
    for (int index = 1; index < count; index++) {
        if (fileContents[index] > highest)
            highest = fileContents[index];
    }
    
    lowest = fileContents[0];                                        // locate lowest value
    for (int index = 1; index < count; index++) {
        if (fileContents[index] < lowest)
            lowest = fileContents[index];
    }
    
    cout << "Total: " << total << endl;                              // display sum
    cout << "Average: " << average << endl;                          // display average
    cout << "Highest: " << highest << endl;                          // display highest
    cout << "Lowest: " << lowest << endl << endl;                    // display lowest
}

void problem7()
{
    
    /*
     This program uses a binary search to search an array of strings.
     */
    
   const int NUM_NAMES = 20;
    string names[NUM_NAMES] = {"Collins, Bill", "Smith, Bart", "Allen, Jim", "Griffin, Jim",
                               "Stamey, Marty", "Rose, Geri", "Taylor, Terri", "Johnson, Jill",
                               "Allison, Jeff", "Looney, Joe", "Wolfe, Bill", "James, Jean",
                               "Weaver, Jim", "Pore, Bob", "Rutherford, Greg", "Javens, Renee",
                               "Harrison, Rose", "Setzer, Cathy", "Pike, Gordon","Holland, Beth"};
    string searchName = "Looney, Joe";
    

    bool swap;
    string temp;
    
    do                                                                          // sort array with bubble sort
    {
        swap = false;
        for (unsigned short count = 0; count < (NUM_NAMES - 1); count++)
        {
            if (names[count] > names[count + 1])
            {
                temp = names[count];
                names[count] = names[count + 1];
                names[count + 1] = temp;
                swap = true;
            }
        }
    } while (swap);
    
    for (int index = 0; index < NUM_NAMES; index++)                             // display sorted array
        cout << names[index] << endl;
    
    cout << endl;
    
                                                                                // search array with binary search

    unsigned short first = 0,
                   last = NUM_NAMES - 1,
                   middle;

    short position = -1;
    
    bool found = false;
    
    while (!found && first <= last)
    {
        middle = (first + last) / 2;
        if (names[middle] == searchName)
        {
            found = true;
            position = middle;
        }
        else if (names[middle] > searchName)
        {
            last = middle - 1;
        }
        else
            first = middle + 1;
    }
    
    
    if (position == -1)                                                         // display search result
        cout << "The name " << searchName << " does not exist in the array.\n";
    else
    {
        cout << "The name " << searchName << " is found at element(s):\n\n";
        cout << position << endl;
    }
}

