#ifndef TIMECLOCK_H
#define	TIMECLOCK_H

#include "MilTime.h"

class TimeClock : public MilTime
{
    public:
        TimeClock();
        TimeClock(signed int, signed int);
        void compute();
    private:
        signed int start;
        signed int finish;
        signed int startmin;
        signed int finishmin;

};

#endif	/* TIMECLOCK_H */

