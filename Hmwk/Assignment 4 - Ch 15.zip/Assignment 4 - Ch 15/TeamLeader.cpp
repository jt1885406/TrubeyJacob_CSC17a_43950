#include "TeamLeader.h"

TeamLeader::TeamLeader(string name, int num, int hdate, int shift, float hourlypayrate, float monthly_bonus_amount, float training_hours, float num_of_training_hours_attended) : ProductionWorker(name, num, hdate, shift, hourlypayrate)
{
    this->monthly_bonus_amount = monthly_bonus_amount;
    this->training_hours = training_hours;
    this->num_of_training_hours_attended = num_of_training_hours_attended;
}

float TeamLeader::getMonthlyBonusAmount()
{
    return this->monthly_bonus_amount;
}

float TeamLeader::getTrainingHours()
{
    return this->training_hours;
}

float TeamLeader::getNumOfTrainingHoursAttended()
{
    return this->num_of_training_hours_attended;
}

void TeamLeader::setMonthlyBonusAmount(float monthly_bonus_amount)
{
    this->monthly_bonus_amount = monthly_bonus_amount;
}

void TeamLeader::setTrainingHours(float training_hours)
{
    this->training_hours = training_hours;
}

void TeamLeader::setNumOfTrainingHoursAttended(float num_of_training_hours_attended)
{
    this->num_of_training_hours_attended = num_of_training_hours_attended;
}

void TeamLeader::showInfo()
{
    cout << "Employee Name -> " << this->employee_name << endl;
    cout << "Employee Number -> " << this->employee_number << endl;
    cout << "Hire Date -> " << this->hire_date << endl;
    cout << "Hourly pay rate -> " << this->hourlypayrate << endl;
    cout << "monthly bonus amount -> " << this->monthly_bonus_amount << endl;
    cout << "training hours -> " << this->training_hours << endl;
    cout << "training hours attended-> " << this->num_of_training_hours_attended << endl;
    
}   



