#include "TimeClock.h"
#include <cmath>

TimeClock::TimeClock() 
{
    this->ampm = "";
    this->finish = 0;
    this->hour = 0;
    this->milHours = 0;
    this->milSeconds = 0;
    this->min = 0;
    this->sec = 0;
    this->start = 0;
    
}

TimeClock::TimeClock(signed int start, signed int finish) 
{
    if(finish >= 0 && finish < 100)
    {
        this->finish = 2400;
    }
    else
        this->finish = finish;  
    
    this->start = start;
    
    this->startmin = this->start % 100;
    this->finishmin = this->finish % 100;
    
    if(this->finishmin == 0 && this->startmin != 0)
        this->finishmin = 100;


}

void TimeClock::compute()
{

    int difference = this->finish - this->start;
    difference = abs(difference);
    difference = difference / 100; 
    
    int difference2 = this->finishmin - this->startmin;
    if(difference2 < 0)
    {
        difference2 = difference2 + 60;
    }
   
   
    cout << difference <<" hours and " << difference2 << " minutes" << endl;
    
}
