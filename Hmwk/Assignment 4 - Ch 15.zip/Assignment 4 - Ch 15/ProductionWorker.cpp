#include "ProductionWorker.h"

using namespace std;

ProductionWorker::ProductionWorker(string name, int num, int hdate, int shift, float hourlypayrate) : Employee(name, num, hdate)
{
    this->shift = shift;
    this->hourlypayrate = hourlypayrate;
}

void ProductionWorker::showInfo()
{
    cout << "Employee Name -> " << this->employee_name << endl;
    cout << "Employee Number -> " << this->employee_number << endl;
    cout << "Hire Date -> " << this->hire_date << endl;
    cout <<  "Current Pay -> " << this->hourlypayrate << endl;
     cout << "Current shift -> " << this->shift << endl;
}   

int ProductionWorker::getShift()
{
    return this->shift;
}

float ProductionWorker::getHourlyPayRate()
{
    return this->hourlypayrate;
}

void ProductionWorker::setShift(int shift)
{
    this->shift = shift;
}

void ProductionWorker::setHourlyPayRate(int hourlypayrate)
{
    this->hourlypayrate = hourlypayrate;
}

