#include "MilTime.h"
#include <string> 

MilTime::MilTime() 
{
    this->hour = 0; 
    this->min = 0; 
    this->sec = 0;
    this->ampm = "";
}

void MilTime::getHour()
{
    if(this->ampm == "AM")
    {
        cout << this->milHours << endl;
    }
    else if(this->ampm == "PM")
    {
        cout << this->milHours << endl;
    }
    else
    {
        cout <<"Not set";         
    }
  
}

void MilTime::getStandHr()
{
    if(this->ampm == "AM")
    {
        cout << this->hour << endl;
    }
    else if(this->ampm == "PM")
    {
        if(this->hour >= 12 && this->hour <= 23)
        {
            cout <<  this->hour << "00PM";
        }  
    }
    else
    {
        cout <<"Not set";         
    }
}

MilTime::MilTime(signed int milHours, signed int milSeconds) 
{
    this->ampm = "";
    setTime(milHours, milSeconds);
          

}

void MilTime::setTime(signed int milHours, signed int milSeconds)
{
    if(milSeconds >= 0 && milSeconds <= 59)
    {
       this->sec = milSeconds;
       this->milSeconds = milSeconds;
    }
    else
    {
        this->sec = 0;
        this->milSeconds = 0;
    }
    
    if(milHours <= 1200 && milHours >= 0000)
    {
        this->milHours = milHours;
        this->ampm = "AM";
        if(milHours == 0)
        {
            this->hour = 12;
            this->min = 0;
        }
        else if(milHours > 0 && milHours < 0100)
        {
            this->hour = 12; 
            if(milHours % 100 > 59)
                this->min = 0;
            else
                this->min = milHours % 100;
        }
        else if(milHours >= 0100 && milHours <= 1200)
        {
            if(milHours == 100)
            {
                this->hour = 1;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
            }
            if(milHours == 200)
            {
                this->hour = 2;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
            }
            if(milHours == 300)
            {
                this->hour = 3;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
            }
            if(milHours == 400)
            {
                this->hour = 4;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                
            }
            if(milHours == 500)
            {
                this->hour = 5;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;  
            }
            if(milHours == 600)
            {
                this->hour = 6;   
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
            }
            if(milHours == 700)
            {
                this->hour = 7;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
            }
            if(milHours == 800)
            {
                this->hour = 8;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
            }
            if(milHours == 900)
            {
                this->hour = 9;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
            }
            if(milHours == 1000)
            {
                this->hour = 10;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
            }
            if(milHours == 1100)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 11;
            }
            if(milHours == 1200)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 12;
            }
        }
    }
    else if (milHours >= 1300 && milHours <= 2400)
    {
        this->milHours = milHours;
        this->ampm = "PM";
        this->hour = milHours - 1200;
        
            if(this->hour == 100)
            {
                this->hour = 1;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
            }
            if(this->hour == 200)
            {
                this->hour = 2;
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
            }
            if(this->hour == 300)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 3;
            }
            if(this->hour == 400)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 4;
            }
            if(this->hour == 500)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 5;
            }
            if(this->hour == 600)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 6;
            }
            if(this->hour == 700)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 7;
            }
            if(this->hour == 800)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 8;
            }
            if(this->hour == 900)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 9;
            }
            if(this->hour == 1000)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 10;
            }
            if(this->hour == 1100)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 11;
            }
            if(this->hour == 1200)
            {
                if(milHours % 100 > 59)
                    this->min = 0;
                else
                    this->min = milHours % 100;
                this->hour = 12;
            }
    }
    else
    {
        this->hour = 0;
        this->milHours = 0;
    }
}
