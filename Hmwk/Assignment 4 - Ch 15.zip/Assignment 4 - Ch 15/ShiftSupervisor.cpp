#include "ShiftSupervisor.h"

using namespace std;

#include <iostream>

ShiftSupervisor::ShiftSupervisor(string name, int num, int hdate, float annual_salary, float annual_production_bonus) : Employee(name, num, hdate)
{
    this->annual_salary = annual_salary;
    this->annual_production_bonus = annual_production_bonus;
}

float ShiftSupervisor::getAnnualSalary()
{
    return this->annual_salary;
}

float ShiftSupervisor::getAnnualProductionBonus()
{
    return this->annual_production_bonus;
}

void ShiftSupervisor::setAnnualSalary(float as)
{
    this->annual_salary = as;
}

void ShiftSupervisor::setAnnualProductionBonus(float apb)
{
    this->annual_production_bonus = apb;
}

void ShiftSupervisor::showInfo()
{
    cout << "Employee Name -> " << this->employee_name << endl;
    cout << "Employee Number -> " << this->employee_number << endl;
    cout << "Hire Date -> " << this->hire_date << endl;
    cout << "Annual Salary -> " << this->annual_salary << endl;
    cout << "Annual Production Bonus (%) -> " << this->annual_production_bonus << endl;
    cout << "Annual Production Bonus (added up) -> " << (((this->annual_production_bonus/100) * this->annual_salary) + this->annual_salary)  << endl;
}   