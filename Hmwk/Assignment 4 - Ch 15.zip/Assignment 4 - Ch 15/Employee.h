#ifndef EMPLOYEE_H
#define	EMPLOYEE_H

using namespace std;
#include <iostream>

class Employee 
{
    public:
        Employee(string, int, int);
        string getName();
        int getHDate();
        int getNum();
        void setName(string);
        void setHDate(int);
        void setNum(int);
    protected:
        string employee_name;
        int employee_number;
        int hire_date;
};

#endif	/* EMPLOYEE_H */

