#include <cstdlib>
#include "Employee.h"
#include <iostream>

Employee::Employee(string n, int i, string d, string p)
{
    name = n;
    idNumber = i;
    department = d;
    position = p;
}

Employee::Employee(string n, int i)
{ 
    name = n;
    idNumber = i;
    department = "";
    position = "";
}

Employee::Employee()
{
    name = "";
    idNumber = 0;
    department = "";
    position = "";
}
