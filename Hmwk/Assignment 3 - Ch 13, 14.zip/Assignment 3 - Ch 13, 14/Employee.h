#include <string>
using namespace std;

#ifndef EMPLOYEE_H
#define	EMPLOYEE_H

class Employee
{
    private:
        string name;
        int idNumber;
        string department;
        string position;

    public:
        Employee(string n, int i, string d, string p);
        Employee(string n, int i);
        Employee();
        void setName(string n)
        {name = n;}
        void setID(int i )
        {idNumber = i;}
        void setDepartment(string d)
        {department = d;}
        void setPosition(string p)
        {position = p;}
        string getName()
        {return name;}
        int getID() const
        {return idNumber;}
        string getDepartment() const
        {return department;}
        string getPosition() const
        {return position;}
};
#endif	/* EMPLOYEE_H */

