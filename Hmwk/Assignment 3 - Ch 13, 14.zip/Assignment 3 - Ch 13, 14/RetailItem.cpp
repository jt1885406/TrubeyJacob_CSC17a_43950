#include "RetailItem.h"

RetailItem::RetailItem(string d, int u, float p)
{
    description = d;
    unitsOnHand = u;
    price = p;

}

RetailItem::RetailItem()
{
    description = "NULL";
    unitsOnHand = 0;
    price = 0;

}

