#include "FuelGauge.h"

#ifndef ODOMETER_H
#define	ODOMETER_H

class Odometer
{
    private:
        float mileage;
        
        
    public: 
        Odometer();
        float getMiles()
        {return mileage;}
         Odometer operator++();   
         FuelGauge fuelgauge;
};

#endif	/* ODOMETER_H */

