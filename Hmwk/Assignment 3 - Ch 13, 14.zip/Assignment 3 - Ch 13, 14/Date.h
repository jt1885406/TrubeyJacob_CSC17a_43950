#include <string>
using namespace std;

#ifndef DATE_H
#define DATE_H

class Date
{
    private:
        int month;
        int day;
        int year;
        string getMonth() const;
    public:
        void setMonth(int);
        void setDay(int);
        void setYear(int y)
        {
            year = y;
        }  
        void date1();
        void date2();
        void date3();
};

#endif	/* DATE_H */

