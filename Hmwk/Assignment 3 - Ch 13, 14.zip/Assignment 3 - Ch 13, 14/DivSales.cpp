
#include "DivSales.h"
#include <iostream>
using namespace std;

void DivSales::sales(float q1, float q2, float q3, float q4)
{
    divsales[0] = q1;
    divsales[1] = q2;
    divsales[2] = q3;
    divsales[3] = q4;
    
    for (int i = 0; i < 4; i++)
    {
        totalsales += divsales[i];
    }   
}
         
float DivSales::returnsale(int index) const
{
    while(index < 0 || index > 3)
    {
       cout << "Re-Enter: ";
           cin >> index;
       cout << endl;
    }
    
    return divsales[index]; 
}

float DivSales::totalsales = 0;

