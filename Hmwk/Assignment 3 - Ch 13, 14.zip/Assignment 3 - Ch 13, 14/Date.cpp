#include <cstdlib>
#include "Date.h"
#include <iostream>

void Date::setMonth(int m)
{
    while(m > 12 || m < 1)
    {
        cout << "Please enter a month between 1 and 12: ";
            cin >> m;
    }
    month = m;
}

void Date::setDay(int d)
{
    while(d > 31 || d < 1)
    {
        cout << "Please enter a day between 1 and 31: ";
            cin >> d;
    } 
    day = d;
}

void Date::date1()
{
    cout << month << "/" << day << "/" << year << endl;
}

void Date::date2()
{
  cout << getMonth() << " " << day << "," << year << endl;
}

void Date::date3()
{
  cout << day << " " << getMonth() << " " << year << endl;
}

string Date::getMonth() const
{
    switch(month)
    {
        case 1:
            return "January";
            break;
        case 2:
            return "February";
            break;
        case 3:
            return "March";
            break;
        case 4:
            return "April";
            break;
        case 5:
            return "May";
            break;
        case 6:
            return "June";
            break;
        case 7:
            return "July";
            break;
        case 8:
            return "August";
            break;
        case 9:
            return "September";
            break;
        case 10:
            return "October";
            break;
        case 11:
            return "November";
            break;
        case 12:
            return "December";
            break;
    };
}
