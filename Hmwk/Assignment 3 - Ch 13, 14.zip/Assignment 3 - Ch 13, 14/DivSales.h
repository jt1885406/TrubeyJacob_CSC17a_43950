#ifndef DIVSALES_H
#define	DIVSALES_H

class DivSales
{
    private:
        float divsales[4];
        static float totalsales;
        
    public:
        void sales(float, float, float, float);
        float returnsale(int) const;
        static float getTotal()
        {return totalsales;}
};

#endif	/* DIVSALES_H */

