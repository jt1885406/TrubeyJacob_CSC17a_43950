#include <string>
using namespace std;

#ifndef CAR_H
#define	CAR_H

class Car
{
    private:
        int yearModel;
        string make;
        int speed;
      
    public:
        Car(int ym, string m);
        int getYealModel() const
        {return yearModel;}
        string getMake() const
        {return make;}
        int getSpeed() const
        {return speed;}
        void accelerate()
        { speed += 5;}
        void brake()
        { speed -= 5;}
};

#endif	/* CAR_H */

