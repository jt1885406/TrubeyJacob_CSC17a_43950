/* 
 * File:   main.cpp
 * Author: Jacob Trubey
 * Purpose: Ch 13, 14
 * Created on May 26, 2015, 6:32 PM
 */

#include <iostream>
#include <iomanip> 
#include <cstdlib>
#include <fstream>
#include <string>
#include "Date.h"
#include "Employee.h"
#include "Car.h"
#include "Personal.h"
#include "RetailItem.h"
#include <string>
#include "DayOfYear.h"
#include "NumDays.h"
#include "DivSales.h"
#include "FuelGauge.h"
#include "Odometer.h"

using namespace std;

int Menu();                                                                     
void dates();                                                                   
void employees();                                                               
void cars();                                                                    
void PersonalInfo();                                                           
void RetailItems();                                                             
void Dates();                                                                   
void DatesV2();                                                                 
void NumDay();                                                                  
void DivisionSales();                                                           
void FuelOdometer();                                                            


int main(int argv,char *argc[])
{
    int selection;
    
    do{ 
      selection=Menu();
        
      switch(selection){
      case 1: dates();break;
      case 2: employees();break;
      case 3: cars();break;
      case 4: PersonalInfo();break;
      case 5: RetailItems();break; 
      case 6: Dates();break;
      case 7: DatesV2();break;
      case 8: NumDay();break;
      case 9: DivisionSales();break;
      case 10: FuelOdometer();break;
      default:   break;
      }
    }while(selection<11);
    cout << endl;
    return 0;
}

int Menu()
{
    int selection;
   
    cout<< "1. dates function"<<endl;
    cout<< "2. employees function"<<endl;
    cout<< "3. cars function"<<endl;
    cout<< "4. PersonalInfo function"<<endl;
    cout<< "5. RetailItems function"<<endl;
    cout<< "6. Dates function"<<endl;
    cout<< "7. Dates version 2 function"<<endl;
    cout<< "8. NumDays function "<<endl;
    cout<< "9. division Sales"<<endl;
    cout<< "10. mileage and odometer function"<<endl;
    cout<< "11. exit \n"<<endl;
    cin >> selection;
    return selection;
}

int getN()
{
       int inN;
       cin>>inN;
       return inN;
}

void def(int inN)
{
    cout<<"You typed "<<inN<<" to exit the program"<<endl;
}

void dates()
{
    Date date;
    int day, month, year;
    
    cout << "Please enter a day: ";
        cin >> day;
    date.setDay(day);
    
    cout << "Please enter a month: ";
        cin >> month; 
    date.setMonth(month);
    
    cout << "Please enter a year: ";
         cin >> year;
    date.setYear(year);
    
    cout << endl;
    date.date1();
    date.date2();
    date.date3();
    cout << endl;
}

void employees()
{
    Employee employees[3] = {  Employee("Susan Meyers", 47899, "Accounting", "Vice President"),
                              Employee("Mark Jones", 39119)}; 
    employees[1].setDepartment("IT");
    employees[1].setPosition("Programmer");
    employees[2].setName("Joy Rogers");
    employees[2].setID(81774);
    employees[2].setDepartment("Manufacturing");
    employees[2].setPosition("Engineer");
    
    cout << endl;
    cout << setw(20) << left << "Name" << setw(20) << "ID Number" << setw(20) << "Department" << setw(20) << "Position" << endl;
    cout << endl;
    for (int i = 0; i < 3; i++)
    {
       cout << setw(20) << left << employees[i].getName() << setw(20) <<  employees[i].getID() << setw(20) <<  employees[i].getDepartment() << setw(20) <<  employees[i].getPosition() << endl;
    }
    cout << endl;
}

void cars()
{
    Car car(2003, "Saturn ION-2");
    
    cout << "Make of car is: ";
    cout << car.getMake() << endl;
    
    cout << "Year of car is: ";
    cout << car.getYealModel() << endl;

    cout << "Current speed of car is: ";
    cout << car.getSpeed() << endl;
    cout << endl;
    
    for(int i = 0; i < 5; i ++)
    {
        cout << "Added 5 MPH to speed" << endl;
        car.accelerate();
    }
    
    cout << endl;
    cout << "Added speed of car is: ";
    cout << car.getSpeed() << endl;
    cout << endl;
    
    for(int i = 0; i < 5; i ++)
    {
        cout << "Reduced 5 MPH from speed" << endl;
        car.brake();
    }
    
    cout << endl;
    cout << "Reduced speed of car is: ";
    cout << car.getSpeed() << endl;
    cout << endl;
}

void PersonalInfo()
{
    Personal person[3];
    
    person[0].setName("John Doe");
    person[0].setAge(21);
    person[0].setNumber("951-000-0000");
    person[0].setAddress("address here");
   
    person[1].setName("Jane Doe");
    person[1].setAge(45);
    person[1].setNumber("951-111-1111");
    person[1].setAddress("address 2 here");
    
    person[2].setName("joe doe");
    person[2].setAge(55);
    person[2].setNumber("951-222-2222");
    person[2].setAddress("address 3");
   
    cout << setw(20) << left << "Name" << setw(50) << "Address" << setw(20) << "Number" << setw(20) << "Age" << endl;
    cout << endl;
    for (int i = 0; i < 3; i++)
    {
       cout << setw(20) << left << person[i].getName() << setw(50) <<  person[i].getAddress() << setw(20) <<  person[i].getNumber() << setw(20) <<  person[i].getAge() << endl;
    }
    cout << endl;
}

void RetailItems()
{
    RetailItem retailitems[3] = {RetailItem("Jacket", 12, 59.95)};
    retailitems[1].setDesc("Designer Jeans");
    retailitems[1].setPrice(34.95);
    retailitems[1].setUnits(40);
    retailitems[2].setDesc("Shirt");
    retailitems[2].setPrice(24.95);
    retailitems[2].setUnits(20);

    cout << setw(20) << left << "Description" << setw(50) << "Units on hand"<< setw(20) << "Price" << setw(20)<< endl;
    cout << endl;
    for (int i = 0; i < 3; i++)
    {
       cout << setw(20) << left << retailitems[i].getDesc() << setw(50) <<  retailitems[i].getUnits() << setw(20) <<  retailitems[i].getPrice() << setw(20) << endl;
    }
    cout << endl;
    
}

void Dates()
{
    int day;
    cout << "Please enter a day: ";
        cin >> day;
    while(day <= 0)
    {
        cout << "Re-enter: ";
            cin >> day;
    }
    DayOfYear dayofyear(day);
    dayofyear.print();
    cout << endl;
}

void DatesV2()
{
    int day; 
    string month;
    
    cout << "Please enter a month: ";
        cin >> month;
        
    cin.ignore();
    
    cout << "Please enter a day: ";
        cin >> day;
        
    while(day <= 0)
    {
        cout << "Re-enter: ";
            cin >> day;
    }
        
    DayOfYear dayofyear(month, day);
    dayofyear.print();
    cout << endl;
}

void NumDay()
{
    float hours1, hours2;
    
    cout << "Enter hours for day 1: ";
        cin >> hours1;
    cout << endl;
    cout << "Enter hours for day 2: ";
        cin >> hours2;
    cout << endl;
    
    NumDays workday1(hours1), workday2(hours2), workday3;
    
    cout << "Days worked for day 1 is: " << workday1.getDays() << endl;
    cout << "Days worked for day 2 is: " << workday2.getDays() << endl;
    workday3 = workday1 + workday2;
    cout << "Days worked for day 2 + day 1 added is: " << workday3.getDays() << endl;
    workday3 = workday2 - workday1;
    cout << "Days worked for day 2 - day 1 added is: " << workday3.getDays() << endl;
    cout << "Hours for day 1 is: " << workday1.getHours() << endl;
    cout << "Hours for day 2 is: " << workday2.getHours() << endl;
    cout << "Lets increment day 1's hours by one 5 times " << endl;
    
    for (int i = 0; i < 5; i++)
    {
       ++workday1;
       cout << "Hours for day 1 is: " << workday1.getHours() << endl;
    }
    
    for (int i = 0; i < 5; i++)
    {
       ++workday2;
       cout << "Hours for day 2 is: " << workday2.getHours() << endl;
    } 
}

void DivisionSales()
{
    DivSales sales[3];
    float quarter[4];
    DivSales::getTotal();

    for(int i = 0; i < 3; i++)
    {
        cout << endl;
        cout << endl;
        cout << "Enter data for division " << i+1 << endl;
        for(int j = 0; j < 4; j++) 
        {
            do{
            cout << "Enter for quarter " << j+1 << ": ";
                cin >> quarter[j];  
            }while(quarter[j] < 0);
        }
        sales[i].sales(quarter[0], quarter[1], quarter[2], quarter[3]);
    }
    
    cout << endl;
    cout << setw(25) << "Summary" << endl;
    for(int i = 0; i < 3; i++)
    {
         cout << "Division " << i+1 << endl;   
         for(int j = 0; j < 4; j++)
         {
            cout  << "\t"  << "Quarter " << j+1 << ": " << sales[i].returnsale(j) << endl;  
         }
    }
    cout << "\t" << "Total sales are: " << DivSales::getTotal() << endl;
    cout << endl;   
}

void FuelOdometer()
{
    Odometer odometer;
    
    cout << "Current fuel in car: " << odometer.fuelgauge.getGallons() << endl;
    
    cout << "We will put 15 gallons of gas in your car" << endl;
    for(int i = 0; i < 15; i++)
    {
        ++odometer.fuelgauge;
        cout << "Current gallons of gas in car: " << odometer.fuelgauge.getGallons() << endl;
    }
    
    cout << "Let\'s start driving" << endl;
    
    for(int i = 0; i < 360; i++)
    {
        ++odometer;
        cout << "Current mileage of car: "<< odometer.getMiles() << endl;
    }
    
    cout << "Car is out of gas: " << odometer.fuelgauge.getGallons()  << endl;
    cout << "With 24 miles to the gallon" << endl;
     
}


