#include <string>
using namespace std;

#ifndef RETAILITEM_H
#define	RETAILITEM_H

class RetailItem
{
    private:
        string description;
        int unitsOnHand;
        float price;
        
    public: 
        RetailItem();
        RetailItem(string d, int u, float p);
        string getDesc()
        {return description;}
        int getUnits()
        {return unitsOnHand;}
        float getPrice()
        {return price;} 
        void setDesc(string d)
        {description = d;}
        void setUnits(int u)
        {unitsOnHand = u;}
        void setPrice(float p)
        {price = p;}
};



#endif	/* RETAILITEM_H */

