#include "Personal.h"

Personal::Personal()
{
    name =  "NULL";
    address = "NULL";
    age = 0;
    number = "NULL";
}
