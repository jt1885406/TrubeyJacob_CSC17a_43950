#include "Car.h"

Car::Car(int ym, string m)
{
    yearModel = ym;
    make = m;
    speed = 0;
}