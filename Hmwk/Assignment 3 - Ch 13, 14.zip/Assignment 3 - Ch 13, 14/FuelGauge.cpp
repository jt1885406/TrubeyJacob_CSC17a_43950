#include "FuelGauge.h"

FuelGauge::FuelGauge()
{
    gallons = 0;
}

FuelGauge FuelGauge::operator++()
{
        ++gallons;
        return *this; 
}

FuelGauge FuelGauge::operator--()
{
        --gallons;
        return *this;
}

