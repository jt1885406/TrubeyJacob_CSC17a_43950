#include <string>
using namespace std;

#ifndef PERSONAL_H
#define	PERSONAL_H

class Personal
{
    private:
        string name;
        string address;
        int age;
        string number;
    public:
        Personal();
        void setName(string n)
        {name = n;}
        void setAddress(string a)
        {address = a;}
        void setAge(int a)
        {age = a;}
        void setNumber(string n)
        {number = n;}
        string getName()
        {return name;}
        string getAddress()
        {return address;}
        int getAge()
        {return age;}
        string getNumber()
        {return number;}  
};


#endif	/* PERSONAL_H */

